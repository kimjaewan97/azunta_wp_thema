<?php
/**
 * Single post template.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

get_header();
?>

<main id="primary" class="site-main">
	<div class="ao-container ao-layout">
		<div class="content-area">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content', 'single' );

				the_post_navigation(
					array(
						'prev_text' => '<span class="nav-subtitle">' . esc_html__( '이전 글', 'azunta-optimize' ) . '</span> <span class="nav-title">%title</span>',
						'next_text' => '<span class="nav-subtitle">' . esc_html__( '다음 글', 'azunta-optimize' ) . '</span> <span class="nav-title">%title</span>',
					)
				);

				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			endwhile;
			?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</main>

<?php
get_footer();
