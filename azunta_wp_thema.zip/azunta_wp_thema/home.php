<?php
/**
 * Blog home / posts index template.
 *
 * Category boxes → latest posts → optional two category columns (Customizer).
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

get_header();

$ao_cat_left  = (int) get_theme_mod( 'azunta_optimize_home_category_left', 0 );
$ao_cat_right = (int) get_theme_mod( 'azunta_optimize_home_category_right', 0 );
$ao_cat_count = absint( get_theme_mod( 'azunta_optimize_home_category_count', 5 ) );
?>

<main id="primary" class="site-main">
	<div class="ao-container ao-layout">
		<div class="content-area ao-home">
			<?php
			// 1) Category boxes (navigation cards).
			get_template_part( 'template-parts/home/section', 'category-boxes' );

			// 2) Latest posts.
			get_template_part( 'template-parts/home/section', 'latest' );
			?>

			<?php if ( $ao_cat_left > 0 || $ao_cat_right > 0 ) : ?>
				<div id="ao-home-categories" class="ao-home-categories">
					<?php
					if ( $ao_cat_left > 0 ) {
						get_template_part(
							'template-parts/home/section',
							'category',
							array(
								'cat_id' => $ao_cat_left,
								'count'  => $ao_cat_count,
								'side'   => 'left',
								'title'  => (string) get_theme_mod( 'azunta_optimize_home_category_left_title', '' ),
							)
						);
					}
					if ( $ao_cat_right > 0 ) {
						get_template_part(
							'template-parts/home/section',
							'category',
							array(
								'cat_id' => $ao_cat_right,
								'count'  => $ao_cat_count,
								'side'   => 'right',
								'title'  => (string) get_theme_mod( 'azunta_optimize_home_category_right_title', '' ),
							)
						);
					}
					?>
				</div>
			<?php endif; ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</main>

<?php
get_footer();
