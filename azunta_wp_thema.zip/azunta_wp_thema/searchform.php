<?php
/**
 * Search form template (inset pill style).
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$azunta_optimize_unique_id = wp_unique_id( 'search-form-' );
?>

<form role="search" method="get" class="search-form search-form--inset" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $azunta_optimize_unique_id ); ?>">
		<?php echo esc_html_x( '검색:', 'label', 'azunta-optimize' ); ?>
	</label>
	<div class="search-form__inner">
		<input
			type="search"
			id="<?php echo esc_attr( $azunta_optimize_unique_id ); ?>"
			class="search-field"
			placeholder="<?php echo esc_attr_x( '검색어를 입력하세요', 'placeholder', 'azunta-optimize' ); ?>"
			value="<?php echo get_search_query(); ?>"
			name="s"
		/>
		<button type="submit" class="search-submit">
			<?php echo esc_html_x( '검색', 'submit button', 'azunta-optimize' ); ?>
		</button>
	</div>
</form>
