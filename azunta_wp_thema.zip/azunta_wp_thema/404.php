<?php
/**
 * 404 template.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

get_header();
?>

<main id="primary" class="site-main">
	<div class="ao-container ao-layout">
		<div class="content-area">
			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php esc_html_e( '페이지를 찾을 수 없습니다', 'azunta-optimize' ); ?></h1>
				</header>

				<div class="page-content">
					<p><?php esc_html_e( '요청하신 페이지가 없습니다. 검색하거나 홈으로 돌아가 보세요.', 'azunta-optimize' ); ?></p>
					<?php get_search_form(); ?>
					<p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( '← 홈으로', 'azunta-optimize' ); ?></a></p>
				</div>
			</section>
		</div>

		<?php get_sidebar(); ?>
	</div>
</main>

<?php
get_footer();
