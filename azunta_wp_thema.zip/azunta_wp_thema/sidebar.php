<?php
/**
 * The sidebar containing theme blocks and optional widgets.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! azunta_optimize_has_sidebar() ) {
	return;
}

if ( ! azunta_optimize_sidebar_has_content() ) {
	return;
}
?>

<aside id="secondary" class="widget-area" role="complementary" aria-label="<?php esc_attr_e( 'Primary sidebar', 'azunta-optimize' ); ?>">
	<?php azunta_optimize_ad( 'sidebar' ); ?>

	<?php if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_search', true ) ) : ?>
		<section class="ao-sidebar-block ao-sidebar-search">
			<h2 class="ao-sidebar-block__title"><?php esc_html_e( '검색', 'azunta-optimize' ); ?></h2>
			<?php get_search_form(); ?>
		</section>
	<?php endif; ?>

	<?php if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_categories', true ) ) : ?>
		<section class="ao-sidebar-block ao-sidebar-categories">
			<h2 class="ao-sidebar-block__title"><?php esc_html_e( '카테고리', 'azunta-optimize' ); ?></h2>
			<nav class="ao-cat-accordion" aria-label="<?php esc_attr_e( '카테고리', 'azunta-optimize' ); ?>">
				<?php azunta_optimize_list_categories_accordion( 0 ); ?>
			</nav>
		</section>
	<?php endif; ?>

	<?php if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_recent_posts', false ) ) : ?>
		<section class="ao-sidebar-block ao-sidebar-recent-posts">
			<h2 class="ao-sidebar-block__title"><?php esc_html_e( '최근 글', 'azunta-optimize' ); ?></h2>
			<ul>
				<?php
				$ao_recent = wp_get_recent_posts(
					array(
						'numberposts' => 5,
						'post_status' => 'publish',
					),
					OBJECT
				);
				if ( ! empty( $ao_recent ) ) {
					foreach ( $ao_recent as $ao_post ) {
						printf(
							'<li><a href="%1$s">%2$s</a></li>',
							esc_url( get_permalink( $ao_post ) ),
							esc_html( get_the_title( $ao_post ) )
						);
					}
				} else {
					echo '<li>' . esc_html__( '최근 글이 없습니다.', 'azunta-optimize' ) . '</li>';
				}
				wp_reset_postdata();
				?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_recent_comments', false ) ) : ?>
		<section class="ao-sidebar-block ao-sidebar-recent-comments">
			<h2 class="ao-sidebar-block__title"><?php esc_html_e( '최근 댓글', 'azunta-optimize' ); ?></h2>
			<ul>
				<?php
				$ao_comments = get_comments(
					array(
						'number'  => 5,
						'status'  => 'approve',
						'post_status' => 'publish',
					)
				);
				if ( ! empty( $ao_comments ) ) {
					foreach ( $ao_comments as $ao_comment ) {
						printf(
							'<li>%1$s <a href="%2$s">%3$s</a></li>',
							esc_html(
								sprintf(
									/* translators: %s: comment author */
									__( '%s 님:', 'azunta-optimize' ),
									$ao_comment->comment_author
								)
							),
							esc_url( get_comment_link( $ao_comment ) ),
							esc_html( get_the_title( (int) $ao_comment->comment_post_ID ) )
						);
					}
				} else {
					echo '<li>' . esc_html__( '댓글이 없습니다.', 'azunta-optimize' ) . '</li>';
				}
				?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_archives', false ) ) : ?>
		<section class="ao-sidebar-block ao-sidebar-archives">
			<h2 class="ao-sidebar-block__title"><?php esc_html_e( '글 보관함', 'azunta-optimize' ); ?></h2>
			<ul>
				<?php
				wp_get_archives(
					array(
						'type'  => 'monthly',
						'limit' => 12,
					)
				);
				?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_widgets', false ) && is_active_sidebar( 'sidebar-1' ) ) : ?>
		<div class="ao-sidebar-widgets">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>
	<?php endif; ?>
</aside>
