<?php
/**
 * The header for our theme.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( '본문으로 건너뛰기', 'azunta-optimize' ); ?></a>

	<header id="masthead" class="site-header" role="banner">
		<div class="ao-container site-header-inner">
			<?php get_template_part( 'template-parts/header/site-branding' ); ?>

			<button
				class="menu-toggle"
				type="button"
				aria-controls="site-navigation"
				aria-expanded="false"
			>
				<span class="menu-toggle-icon" aria-hidden="true"></span>
				<span class="menu-toggle-text"><?php esc_html_e( '메뉴', 'azunta-optimize' ); ?></span>
			</button>

			<?php get_template_part( 'template-parts/navigation/primary' ); ?>
		</div>

		<?php if ( is_active_sidebar( 'header-1' ) ) : ?>
			<div class="ao-container header-widget-area">
				<?php dynamic_sidebar( 'header-1' ); ?>
			</div>
		<?php endif; ?>
	</header>

	<?php azunta_optimize_ad( 'header' ); ?>

	<div id="content" class="site-content">
