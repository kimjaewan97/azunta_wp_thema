<?php
/**
 * Azunta Optimize functions and definitions.
 *
 * @package Azunta_Optimize
 * @since 1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AZUNTA_OPTIMIZE_VERSION', '1.2.0' );
define( 'AZUNTA_OPTIMIZE_DIR', get_template_directory() );
define( 'AZUNTA_OPTIMIZE_URI', get_template_directory_uri() );

/**
 * Load theme modules.
 */
$azunta_optimize_includes = array(
	'/inc/setup.php',
	'/inc/enqueue.php',
	'/inc/layout.php',
	'/inc/widgets.php',
	'/inc/template-tags.php',
	'/inc/comments.php',
	'/inc/performance.php',
	'/inc/ads.php',
	'/inc/homepage.php',
	'/inc/customizer.php',
);

foreach ( $azunta_optimize_includes as $azunta_optimize_file ) {
	$azunta_optimize_path = AZUNTA_OPTIMIZE_DIR . $azunta_optimize_file;
	if ( is_readable( $azunta_optimize_path ) ) {
		require_once $azunta_optimize_path;
	}
}
