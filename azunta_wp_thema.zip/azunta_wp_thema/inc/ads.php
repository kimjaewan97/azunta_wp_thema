<?php
/**
 * AdSense / ad slot engine.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registered ad slots and their human labels.
 *
 * @return array<string, string>
 */
function azunta_optimize_get_ad_slots(): array {
	return array(
		'header'           => __( 'Header Ad', 'azunta-optimize' ),
		'after_title'      => __( 'After Title Ad', 'azunta-optimize' ),
		'in_content_2'     => __( 'In-Content Ad (after 2nd paragraph)', 'azunta-optimize' ),
		'in_content_5'     => __( 'In-Content Ad (after 5th paragraph)', 'azunta-optimize' ),
		'end_content'      => __( 'End of Content Ad', 'azunta-optimize' ),
		'sidebar'          => __( 'Sidebar Ad', 'azunta-optimize' ),
		'footer'           => __( 'Footer Ad', 'azunta-optimize' ),
		'archive_between'  => __( 'Archive / Blog Between Posts Ad', 'azunta-optimize' ),
	);
}

/**
 * Allowed HTML for ad code (AdSense-friendly).
 *
 * @return array<string, array<string, bool>>
 */
function azunta_optimize_ad_allowed_html(): array {
	$common_attrs = array(
		'class'                       => true,
		'id'                          => true,
		'style'                       => true,
		'title'                       => true,
		'role'                        => true,
		'aria-label'                  => true,
		'aria-hidden'                 => true,
		'data-ad-client'              => true,
		'data-ad-slot'                => true,
		'data-ad-format'              => true,
		'data-ad-layout'              => true,
		'data-ad-layout-key'          => true,
		'data-full-width-responsive'  => true,
		'data-ad-channel'             => true,
		'data-adtest'                 => true,
		'data-override-id'            => true,
		'width'                       => true,
		'height'                      => true,
		'align'                       => true,
	);

	return array(
		'div'    => $common_attrs,
		'span'   => $common_attrs,
		'ins'    => array_merge(
			$common_attrs,
			array(
				'data-ad-client'             => true,
				'data-ad-slot'               => true,
				'data-ad-format'             => true,
				'data-full-width-responsive' => true,
			)
		),
		'script' => array(
			'type'        => true,
			'src'         => true,
			'async'       => true,
			'defer'       => true,
			'crossorigin' => true,
			'charset'     => true,
			'data-ad-client' => true,
			'data-nscript'   => true,
		),
		'iframe' => array(
			'src'             => true,
			'width'           => true,
			'height'          => true,
			'style'           => true,
			'class'           => true,
			'id'              => true,
			'frameborder'     => true,
			'scrolling'       => true,
			'marginwidth'     => true,
			'marginheight'    => true,
			'allow'           => true,
			'allowfullscreen' => true,
			'loading'         => true,
			'title'           => true,
		),
		'style'  => array(
			'type' => true,
		),
		'noscript' => array(),
		'img'    => array(
			'src'    => true,
			'alt'    => true,
			'width'  => true,
			'height' => true,
			'class'  => true,
			'style'  => true,
			'border' => true,
		),
		'a'      => array(
			'href'   => true,
			'target' => true,
			'rel'    => true,
			'class'  => true,
			'style'  => true,
		),
	);
}

/**
 * Sanitize ad code from Customizer.
 *
 * Admins with unfiltered_html keep full AdSense snippets (incl. inline JS).
 * Others get an extended wp_kses allow-list.
 *
 * @param string $value Raw ad markup.
 * @return string
 */
function azunta_optimize_sanitize_ad_code( string $value ): string {
	$value = trim( $value );
	if ( '' === $value ) {
		return '';
	}

	// Theme Customizer is limited to users who can edit theme options.
	// Preserve complete AdSense units for trusted admins.
	if ( function_exists( 'current_user_can' ) && current_user_can( 'unfiltered_html' ) ) {
		// Light cleanup only: null bytes.
		return str_replace( "\0", '', $value );
	}

	return wp_kses( $value, azunta_optimize_ad_allowed_html() );
}

/**
 * Sanitize checkbox / boolean theme mods.
 *
 * @param mixed $checked Raw value.
 * @return bool
 */
function azunta_optimize_sanitize_checkbox( $checked ): bool {
	return (bool) $checked;
}

/**
 * Whether ads should be shown globally / for a slot.
 *
 * @param string $slot Slot key.
 * @return bool
 */
function azunta_optimize_should_show_ads( string $slot = '' ): bool {
	$show = true;

	if ( is_admin() || is_feed() || wp_is_json_request() ) {
		$show = false;
	}

	if ( $show && ! (bool) get_theme_mod( 'azunta_optimize_ads_global_enable', true ) ) {
		$show = false;
	}

	// Hide ads from logged-in users unless explicitly allowed.
	if ( $show && is_user_logged_in() && ! (bool) get_theme_mod( 'azunta_optimize_ads_show_to_logged_in', false ) ) {
		$show = false;
	}

	if ( $show && '' !== $slot ) {
		$enabled = (bool) get_theme_mod( 'azunta_optimize_ads_' . $slot . '_enable', false );
		$code    = (string) get_theme_mod( 'azunta_optimize_ads_' . $slot . '_code', '' );
		if ( ! $enabled || '' === trim( $code ) ) {
			$show = false;
		}
	}

	/**
	 * Filter whether ads should display.
	 *
	 * @param bool   $show Whether to show.
	 * @param string $slot Slot key (may be empty for global checks).
	 */
	return (bool) apply_filters( 'azunta_optimize_should_show_ads', $show, $slot );
}

/**
 * Get ad code for a slot.
 *
 * Code is sanitized on save via Customizer; do not re-run capability-based
 * kses on the front end (logged-out visitors lack unfiltered_html).
 *
 * @param string $slot Slot key.
 * @return string
 */
function azunta_optimize_get_ad_code( string $slot ): string {
	$code = (string) get_theme_mod( 'azunta_optimize_ads_' . $slot . '_code', '' );
	$code = str_replace( "\0", '', $code );

	/**
	 * Filter ad HTML before output.
	 *
	 * @param string $code Ad unit markup.
	 * @param string $slot Slot key.
	 */
	return (string) apply_filters( 'azunta_optimize_ad_html', $code, $slot );
}

/**
 * Render an ad slot.
 *
 * @param string $slot Slot key.
 * @return void
 */
function azunta_optimize_ad( string $slot ): void {
	if ( ! azunta_optimize_should_show_ads( $slot ) ) {
		return;
	}

	$code = azunta_optimize_get_ad_code( $slot );
	if ( '' === $code ) {
		return;
	}

	$slots = azunta_optimize_get_ad_slots();
	$label = isset( $slots[ $slot ] ) ? $slots[ $slot ] : $slot;

	get_template_part(
		'template-parts/ads/slot',
		null,
		array(
			'slot'  => $slot,
			'code'  => $code,
			'label' => $label,
		)
	);
}

/**
 * Get in-content paragraph positions map.
 *
 * @return array<int, string> Paragraph number (1-based) => slot key.
 */
function azunta_optimize_get_in_content_positions(): array {
	$positions = array(
		2 => 'in_content_2',
		5 => 'in_content_5',
	);

	/**
	 * Filter in-content ad positions.
	 *
	 * @param array<int, string> $positions Map of paragraph index => slot.
	 */
	return (array) apply_filters( 'azunta_optimize_in_content_positions', $positions );
}

/**
 * Render ad slot HTML string (no echo).
 *
 * @param string $slot Slot key.
 * @return string
 */
function azunta_optimize_get_ad_markup( string $slot ): string {
	if ( ! azunta_optimize_should_show_ads( $slot ) ) {
		return '';
	}

	$code = azunta_optimize_get_ad_code( $slot );
	if ( '' === $code ) {
		return '';
	}

	$slots = azunta_optimize_get_ad_slots();
	$label = isset( $slots[ $slot ] ) ? $slots[ $slot ] : $slot;

	ob_start();
	get_template_part(
		'template-parts/ads/slot',
		null,
		array(
			'slot'  => $slot,
			'code'  => $code,
			'label' => $label,
		)
	);
	return (string) ob_get_clean();
}

/**
 * Insert ads after specific paragraphs in post content.
 *
 * Uses closing </p> tags so lists, images, and block markup stay intact.
 * Also appends the end-of-content ad on singular views.
 *
 * @param string $content Post content.
 * @return string
 */
function azunta_optimize_insert_in_content_ads( string $content ): string {
	if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	if ( post_password_required() ) {
		return $content;
	}

	$output     = $content;
	$post_types = (array) apply_filters( 'azunta_optimize_in_content_post_types', array( 'post' ) );

	// In-content paragraph ads (default: posts only).
	if ( in_array( get_post_type(), $post_types, true ) ) {
		$positions = azunta_optimize_get_in_content_positions();
		$slot_html = array();

		foreach ( $positions as $para => $slot ) {
			$markup = azunta_optimize_get_ad_markup( $slot );
			if ( '' !== $markup ) {
				$slot_html[ (int) $para ] = $markup;
			}
		}

		if ( ! empty( $slot_html ) ) {
			$min_paragraphs = absint( get_theme_mod( 'azunta_optimize_ads_in_content_min_paragraphs', 3 ) );
			if ( $min_paragraphs < 1 ) {
				$min_paragraphs = 1;
			}

			$parts = preg_split( '/(<\/p>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
			if ( is_array( $parts ) && count( $parts ) >= 2 ) {
				$p_count = 0;
				foreach ( $parts as $part ) {
					if ( preg_match( '/^<\/p>$/i', $part ) ) {
						++$p_count;
					}
				}

				if ( $p_count >= $min_paragraphs ) {
					$output      = '';
					$para_index  = 0;
					$parts_count = count( $parts );

					for ( $i = 0; $i < $parts_count; $i++ ) {
						$output .= $parts[ $i ];
						if ( preg_match( '/^<\/p>$/i', $parts[ $i ] ) ) {
							++$para_index;
							if ( isset( $slot_html[ $para_index ] ) ) {
								$output .= $slot_html[ $para_index ];
							}
						}
					}
				}
			}
		}
	}

	// End of content ad (singular posts and pages).
	$end = azunta_optimize_get_ad_markup( 'end_content' );
	if ( '' !== $end ) {
		$output .= $end;
	}

	return $output;
}
add_filter( 'the_content', 'azunta_optimize_insert_in_content_ads', 12 );

/**
 * Print AdSense loader once in head when publisher ID is set.
 */
function azunta_optimize_adsense_loader(): void {
	if ( ! azunta_optimize_should_show_ads() ) {
		return;
	}

	$pub = (string) get_theme_mod( 'azunta_optimize_ads_publisher_id', '' );
	$pub = sanitize_text_field( $pub );

	if ( '' === $pub || ! (bool) get_theme_mod( 'azunta_optimize_ads_load_script', true ) ) {
		return;
	}

	// Expect ca-pub-XXXXXXXX.
	if ( ! preg_match( '/^ca-pub-\d+$/', $pub ) ) {
		return;
	}

	printf(
		'<script async src="%s" crossorigin="anonymous"></script>' . "\n",
		esc_url( 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . rawurlencode( $pub ) )
	);
}
add_action( 'wp_head', 'azunta_optimize_adsense_loader', 5 );

/**
 * Whether to render archive between-posts ad after current loop index.
 *
 * @param int $index Zero-based loop index (or 1-based current_post).
 * @return bool
 */
function azunta_optimize_should_show_archive_ad( int $index ): bool {
	if ( ! azunta_optimize_should_show_ads( 'archive_between' ) ) {
		return false;
	}

	$interval = absint( get_theme_mod( 'azunta_optimize_ads_archive_interval', 3 ) );
	if ( $interval < 1 ) {
		$interval = 3;
	}

	// Show after every Nth post (1-based position).
	$position = $index + 1;
	return ( 0 === $position % $interval );
}
