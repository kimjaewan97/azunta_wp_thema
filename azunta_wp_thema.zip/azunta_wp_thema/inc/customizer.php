<?php
/**
 * Theme Customizer: Layout, Ads, Performance.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Customizer settings and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function azunta_optimize_customize_register( WP_Customize_Manager $wp_customize ): void {
	// -------------------------------------------------------------------------
	// Panel
	// -------------------------------------------------------------------------
	$wp_customize->add_panel(
		'azunta_optimize_panel',
		array(
			'title'       => __( 'Azunta Optimize', 'azunta-optimize' ),
			'description' => __( 'Layout, AdSense slots, and performance options.', 'azunta-optimize' ),
			'priority'    => 30,
		)
	);

	// -------------------------------------------------------------------------
	// Layout section
	// -------------------------------------------------------------------------
	$wp_customize->add_section(
		'azunta_optimize_layout',
		array(
			'title'    => __( 'Layout', 'azunta-optimize' ),
			'panel'    => 'azunta_optimize_panel',
			'priority' => 10,
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_container_width',
		array(
			'default'           => 1200,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_container_width',
		array(
			'label'       => __( 'Container width (px)', 'azunta-optimize' ),
			'description' => __( 'Overall content container. Recommended 1100–1200.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_layout',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 960,
				'max'  => 1400,
				'step' => 10,
			),
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_sidebar_position',
		array(
			'default'           => 'right',
			'sanitize_callback' => 'azunta_optimize_sanitize_sidebar_position',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_sidebar_position',
		array(
			'label'   => __( 'Sidebar position', 'azunta-optimize' ),
			'section' => 'azunta_optimize_layout',
			'type'    => 'select',
			'choices' => array(
				'right' => __( 'Right sidebar', 'azunta-optimize' ),
				'left'  => __( 'Left sidebar', 'azunta-optimize' ),
				'none'  => __( 'No sidebar', 'azunta-optimize' ),
			),
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_content_width_no_sidebar',
		array(
			'default'           => 800,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_content_width_no_sidebar',
		array(
			'label'       => __( 'Content max-width without sidebar (px)', 'azunta-optimize' ),
			'description' => __( 'Keeps long-form text readable when sidebar is disabled.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_layout',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 600,
				'max'  => 1200,
				'step' => 10,
			),
		)
	);

	// -------------------------------------------------------------------------
	// Single Post section
	// -------------------------------------------------------------------------
	$wp_customize->add_section(
		'azunta_optimize_single',
		array(
			'title'       => __( 'Single Post', 'azunta-optimize' ),
			'description' => __( 'Single post display options. Ad slots (After Title, In-content, End of Content) are under Ads / AdSense.', 'azunta-optimize' ),
			'panel'       => 'azunta_optimize_panel',
			'priority'    => 12,
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_show_single_meta',
		array(
			'default'           => false,
			'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_show_single_meta',
		array(
			'label'       => __( 'Show date and author on single posts', 'azunta-optimize' ),
			'description' => __( 'Off by default. Enable to show “Posted on … by …” under the title.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_single',
			'type'        => 'checkbox',
		)
	);

	// -------------------------------------------------------------------------
	// Homepage section
	// -------------------------------------------------------------------------
	$wp_customize->add_section(
		'azunta_optimize_homepage',
		array(
			'title'       => __( 'Homepage', 'azunta-optimize' ),
			'description' => __( 'Latest posts section and two category columns on the blog home (home.php).', 'azunta-optimize' ),
			'panel'       => 'azunta_optimize_panel',
			'priority'    => 15,
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_home_latest_title',
		array(
			'default'           => '최신 글',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_home_latest_title',
		array(
			'label'   => __( 'Latest posts section title', 'azunta-optimize' ),
			'section' => 'azunta_optimize_homepage',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_home_latest_count',
		array(
			'default'           => 10,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_home_latest_count',
		array(
			'label'       => __( 'Latest posts count', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_homepage',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 1,
				'max'  => 30,
				'step' => 1,
			),
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_home_category_left',
		array(
			'default'           => 0,
			'sanitize_callback' => 'azunta_optimize_sanitize_category_id',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_home_category_left',
		array(
			'label'       => __( 'Category Left', 'azunta-optimize' ),
			'description' => __( 'Left column category (5 recent posts by default).', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_homepage',
			'type'        => 'select',
			'choices'     => azunta_optimize_get_category_choices(),
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_home_category_left_title',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_home_category_left_title',
		array(
			'label'       => __( 'Category Left title (optional)', 'azunta-optimize' ),
			'description' => __( 'Leave empty to use the category name.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_homepage',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_home_category_right',
		array(
			'default'           => 0,
			'sanitize_callback' => 'azunta_optimize_sanitize_category_id',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_home_category_right',
		array(
			'label'       => __( 'Category Right', 'azunta-optimize' ),
			'description' => __( 'Right column category (5 recent posts by default).', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_homepage',
			'type'        => 'select',
			'choices'     => azunta_optimize_get_category_choices(),
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_home_category_right_title',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_home_category_right_title',
		array(
			'label'       => __( 'Category Right title (optional)', 'azunta-optimize' ),
			'description' => __( 'Leave empty to use the category name.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_homepage',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_home_category_count',
		array(
			'default'           => 5,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_home_category_count',
		array(
			'label'       => __( 'Posts per category column', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_homepage',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 1,
				'max'  => 20,
				'step' => 1,
			),
		)
	);

	// -------------------------------------------------------------------------
	// Sidebar section
	// -------------------------------------------------------------------------
	$wp_customize->add_section(
		'azunta_optimize_sidebar',
		array(
			'title'       => __( 'Sidebar', 'azunta-optimize' ),
			'description' => __( 'Theme sidebar blocks. By default only Search and Categories (accordion) are shown.', 'azunta-optimize' ),
			'panel'       => 'azunta_optimize_panel',
			'priority'    => 18,
		)
	);

	$sidebar_toggles = array(
		'sidebar_show_search'           => array(
			'label'   => __( 'Show search', 'azunta-optimize' ),
			'default' => true,
		),
		'sidebar_show_categories'       => array(
			'label'   => __( 'Show categories (accordion)', 'azunta-optimize' ),
			'default' => true,
		),
		'sidebar_show_recent_posts'     => array(
			'label'   => __( 'Show recent posts', 'azunta-optimize' ),
			'default' => false,
		),
		'sidebar_show_recent_comments'  => array(
			'label'   => __( 'Show recent comments', 'azunta-optimize' ),
			'default' => false,
		),
		'sidebar_show_archives'         => array(
			'label'   => __( 'Show archives', 'azunta-optimize' ),
			'default' => false,
		),
		'sidebar_show_widgets'          => array(
			'label'       => __( 'Show widget area (sidebar-1)', 'azunta-optimize' ),
			'description' => __( 'Enable to also display widgets from Appearance → Widgets.', 'azunta-optimize' ),
			'default'     => false,
		),
	);

	foreach ( $sidebar_toggles as $mod_key => $config ) {
		$setting_id = 'azunta_optimize_' . $mod_key;
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $config['default'],
				'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
			)
		);
		$control = array(
			'label'   => $config['label'],
			'section' => 'azunta_optimize_sidebar',
			'type'    => 'checkbox',
		);
		if ( ! empty( $config['description'] ) ) {
			$control['description'] = $config['description'];
		}
		$wp_customize->add_control( $setting_id, $control );
	}

	// -------------------------------------------------------------------------
	// Ads section
	// -------------------------------------------------------------------------
	$wp_customize->add_section(
		'azunta_optimize_ads',
		array(
			'title'       => __( 'Ads / AdSense', 'azunta-optimize' ),
			'description' => __( 'Control AdSense publisher ID and each ad slot. Paste unit code from AdSense. See theme README for placement map.', 'azunta-optimize' ),
			'panel'       => 'azunta_optimize_panel',
			'priority'    => 20,
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_ads_global_enable',
		array(
			'default'           => true,
			'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_ads_global_enable',
		array(
			'label'   => __( 'Enable ads site-wide', 'azunta-optimize' ),
			'section' => 'azunta_optimize_ads',
			'type'    => 'checkbox',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_ads_show_to_logged_in',
		array(
			'default'           => false,
			'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_ads_show_to_logged_in',
		array(
			'label'       => __( 'Show ads to logged-in users', 'azunta-optimize' ),
			'description' => __( 'Off by default so admins can browse without ads. Enable to preview placements while logged in.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_ads',
			'type'        => 'checkbox',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_ads_publisher_id',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_ads_publisher_id',
		array(
			'label'       => __( 'AdSense Publisher ID', 'azunta-optimize' ),
			'description' => __( 'Format: ca-pub-XXXXXXXXXXXXXXXX. Used to load adsbygoogle.js once in the head.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_ads',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_ads_load_script',
		array(
			'default'           => true,
			'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_ads_load_script',
		array(
			'label'       => __( 'Auto-load AdSense script from Publisher ID', 'azunta-optimize' ),
			'description' => __( 'Disable if every unit code already includes the adsbygoogle.js script tag.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_ads',
			'type'        => 'checkbox',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_ads_archive_interval',
		array(
			'default'           => 3,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_ads_archive_interval',
		array(
			'label'       => __( 'Archive: show ad every N posts', 'azunta-optimize' ),
			'description' => __( 'Inserts the Archive Between Posts ad after every Nth post in loops.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_ads',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 1,
				'max'  => 20,
				'step' => 1,
			),
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_ads_in_content_min_paragraphs',
		array(
			'default'           => 3,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_ads_in_content_min_paragraphs',
		array(
			'label'       => __( 'In-content: minimum paragraphs', 'azunta-optimize' ),
			'description' => __( 'Skip in-content ads if the post has fewer than this many paragraphs.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_ads',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 1,
				'max'  => 20,
				'step' => 1,
			),
		)
	);

	// Per-slot controls.
	$slots = azunta_optimize_get_ad_slots();
	$priority = 50;

	foreach ( $slots as $slot => $label ) {
		$wp_customize->add_setting(
			'azunta_optimize_ads_' . $slot . '_enable',
			array(
				'default'           => false,
				'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
			)
		);
		$wp_customize->add_control(
			'azunta_optimize_ads_' . $slot . '_enable',
			array(
				'label'    => sprintf(
					/* translators: %s: ad slot name */
					__( 'Enable: %s', 'azunta-optimize' ),
					$label
				),
				'section'  => 'azunta_optimize_ads',
				'type'     => 'checkbox',
				'priority' => $priority,
			)
		);

		$wp_customize->add_setting(
			'azunta_optimize_ads_' . $slot . '_code',
			array(
				'default'           => '',
				'sanitize_callback' => 'azunta_optimize_sanitize_ad_code',
			)
		);
		$wp_customize->add_control(
			'azunta_optimize_ads_' . $slot . '_code',
			array(
				'label'       => sprintf(
					/* translators: %s: ad slot name */
					__( 'Code: %s', 'azunta-optimize' ),
					$label
				),
				'description' => __( 'Paste the AdSense unit code (or responsive ad snippet).', 'azunta-optimize' ),
				'section'     => 'azunta_optimize_ads',
				'type'        => 'textarea',
				'priority'    => $priority + 1,
			)
		);

		$priority += 10;
	}

	// -------------------------------------------------------------------------
	// Performance section
	// -------------------------------------------------------------------------
	$wp_customize->add_section(
		'azunta_optimize_performance',
		array(
			'title'    => __( 'Performance', 'azunta-optimize' ),
			'panel'    => 'azunta_optimize_panel',
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_disable_emojis',
		array(
			'default'           => true,
			'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_disable_emojis',
		array(
			'label'   => __( 'Disable WordPress emoji scripts', 'azunta-optimize' ),
			'section' => 'azunta_optimize_performance',
			'type'    => 'checkbox',
		)
	);

	$wp_customize->add_setting(
		'azunta_optimize_disable_wp_embed',
		array(
			'default'           => false,
			'sanitize_callback' => 'azunta_optimize_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'azunta_optimize_disable_wp_embed',
		array(
			'label'       => __( 'Disable wp-embed script', 'azunta-optimize' ),
			'description' => __( 'May affect oEmbed of your posts on other sites. Leave off if unsure.', 'azunta-optimize' ),
			'section'     => 'azunta_optimize_performance',
			'type'        => 'checkbox',
		)
	);
}
add_action( 'customize_register', 'azunta_optimize_customize_register' );

/**
 * Sanitize sidebar position.
 *
 * @param string $value Raw value.
 * @return string
 */
function azunta_optimize_sanitize_sidebar_position( string $value ): string {
	$allowed = array( 'left', 'right', 'none' );
	return in_array( $value, $allowed, true ) ? $value : 'right';
}
