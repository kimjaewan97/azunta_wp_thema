<?php
/**
 * Category pin: pin selected posts to the top within a category.
 *
 * Post meta key: _azunta_category_pin (one row per category term ID).
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var string Post meta key; value is category term ID (multiple rows allowed). */
const AZUNTA_OPTIMIZE_CATEGORY_PIN_META = '_azunta_category_pin';

/**
 * Register meta box on post edit screen.
 */
function azunta_optimize_category_pin_meta_box(): void {
	add_meta_box(
		'azunta_optimize_category_pin',
		__( '카테고리 상단 고정', 'azunta-optimize' ),
		'azunta_optimize_render_category_pin_meta_box',
		'post',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'azunta_optimize_category_pin_meta_box' );

/**
 * Render the category pin meta box.
 *
 * @param WP_Post $post Current post.
 */
function azunta_optimize_render_category_pin_meta_box( WP_Post $post ): void {
	wp_nonce_field( 'azunta_optimize_save_category_pins', 'azunta_optimize_category_pins_nonce' );

	$pinned    = azunta_optimize_get_post_category_pins( (int) $post->ID );
	$post_cats = wp_get_post_categories( (int) $post->ID, array( 'fields' => 'all' ) );

	echo '<p class="description" style="margin-top:0;">';
	esc_html_e( '선택한 카테고리 목록에서 이 글을 맨 위에 고정합니다. 글이 속한 카테고리만 선택할 수 있습니다.', 'azunta-optimize' );
	echo '</p>';

	if ( empty( $post_cats ) || is_wp_error( $post_cats ) ) {
		echo '<p><em>';
		esc_html_e( '먼저 카테고리를 지정한 뒤 업데이트하세요.', 'azunta-optimize' );
		echo '</em></p>';
		return;
	}

	echo '<ul style="margin:0;padding-left:0;list-style:none;">';
	foreach ( $post_cats as $term ) {
		if ( ! $term instanceof WP_Term ) {
			continue;
		}
		$tid     = (int) $term->term_id;
		$checked = in_array( $tid, $pinned, true );
		printf(
			'<li style="margin:0.4em 0;"><label><input type="checkbox" name="azunta_category_pins[]" value="%1$d"%2$s /> %3$s</label></li>',
			$tid,
			$checked ? ' checked="checked"' : '',
			esc_html( $term->name )
		);
	}
	echo '</ul>';
}

/**
 * Save category pin meta when post is saved.
 *
 * @param int $post_id Post ID.
 */
function azunta_optimize_save_category_pins( int $post_id ): void {
	if ( ! isset( $_POST['azunta_optimize_category_pins_nonce'] ) ) {
		return;
	}

	$nonce = sanitize_text_field( wp_unslash( (string) $_POST['azunta_optimize_category_pins_nonce'] ) );
	if ( ! wp_verify_nonce( $nonce, 'azunta_optimize_save_category_pins' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( 'post' !== get_post_type( $post_id ) ) {
		return;
	}

	// Categories previously pinned (for cache clear).
	$old_pins = azunta_optimize_get_post_category_pins( $post_id );

	$raw = isset( $_POST['azunta_category_pins'] ) ? (array) wp_unslash( $_POST['azunta_category_pins'] ) : array();
	$ids = array();
	foreach ( $raw as $id ) {
		$id = absint( $id );
		if ( $id > 0 ) {
			$ids[] = $id;
		}
	}
	$ids = array_values( array_unique( $ids ) );

	// Prefer categories from the save request (terms may not be committed yet).
	$post_cat_ids = array();
	if ( isset( $_POST['post_category'] ) && is_array( $_POST['post_category'] ) ) {
		foreach ( (array) wp_unslash( $_POST['post_category'] ) as $raw_cat ) {
			$cid = absint( $raw_cat );
			if ( $cid > 0 ) {
				$post_cat_ids[] = $cid;
			}
		}
	} else {
		$from_db = wp_get_post_categories( $post_id );
		if ( is_array( $from_db ) ) {
			$post_cat_ids = array_map( 'intval', $from_db );
		}
	}
	$post_cat_ids = array_values( array_unique( $post_cat_ids ) );
	$ids          = array_values( array_intersect( $ids, $post_cat_ids ) );

	delete_post_meta( $post_id, AZUNTA_OPTIMIZE_CATEGORY_PIN_META );
	foreach ( $ids as $cat_id ) {
		add_post_meta( $post_id, AZUNTA_OPTIMIZE_CATEGORY_PIN_META, $cat_id, false );
	}

	$clear_cats = array_unique( array_merge( $old_pins, $ids, is_array( $post_cat_ids ) ? $post_cat_ids : array() ) );
	foreach ( $clear_cats as $cat_id ) {
		wp_cache_delete( 'ao_cat_pins_' . (int) $cat_id, 'azunta_optimize' );
	}
}
add_action( 'save_post', 'azunta_optimize_save_category_pins' );

/**
 * Get category IDs where a post is pinned.
 *
 * @param int $post_id Post ID.
 * @return int[]
 */
function azunta_optimize_get_post_category_pins( int $post_id ): array {
	$raw = get_post_meta( $post_id, AZUNTA_OPTIMIZE_CATEGORY_PIN_META, false );
	if ( ! is_array( $raw ) || empty( $raw ) ) {
		return array();
	}

	$ids = array();
	foreach ( $raw as $id ) {
		$id = absint( $id );
		if ( $id > 0 ) {
			$ids[] = $id;
		}
	}

	return array_values( array_unique( $ids ) );
}

/**
 * Whether a post is pinned in a given category.
 *
 * @param int $post_id Post ID.
 * @param int $cat_id  Category term ID.
 * @return bool
 */
function azunta_optimize_is_post_pinned_in_category( int $post_id, int $cat_id ): bool {
	if ( $post_id <= 0 || $cat_id <= 0 ) {
		return false;
	}
	return in_array( $cat_id, azunta_optimize_get_post_category_pins( $post_id ), true );
}

/**
 * Get post IDs pinned to a category (date DESC among pinned).
 *
 * @param int $cat_id Category term ID.
 * @return int[]
 */
function azunta_optimize_get_category_pinned_post_ids( int $cat_id ): array {
	if ( $cat_id <= 0 ) {
		return array();
	}

	$cache_key = 'ao_cat_pins_' . $cat_id;
	$cached    = wp_cache_get( $cache_key, 'azunta_optimize' );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$query = new WP_Query(
		array(
			'post_type'              => 'post',
			'post_status'            => 'publish',
			'posts_per_page'         => 50,
			'fields'                 => 'ids',
			'cat'                    => $cat_id,
			'ignore_sticky_posts'    => true,
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => AZUNTA_OPTIMIZE_CATEGORY_PIN_META,
					'value'   => $cat_id,
					'compare' => '=',
					'type'    => 'NUMERIC',
				),
			),
			'orderby'                => 'date',
			'order'                  => 'DESC',
		)
	);

	$ids = array_map( 'intval', $query->posts );
	wp_cache_set( $cache_key, $ids, 'azunta_optimize', 5 * MINUTE_IN_SECONDS );

	return $ids;
}

/**
 * On category archives, order pinned posts first.
 *
 * @param WP_Query $query Main query.
 */
function azunta_optimize_category_pin_pre_get_posts( WP_Query $query ): void {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_category() ) {
		return;
	}

	$cat_id = (int) $query->get_queried_object_id();
	if ( $cat_id <= 0 ) {
		return;
	}

	$pinned = azunta_optimize_get_category_pinned_post_ids( $cat_id );
	if ( empty( $pinned ) ) {
		return;
	}

	$query->set( 'azunta_category_pin_ids', $pinned );
	$query->set( 'ignore_sticky_posts', true );
}
add_action( 'pre_get_posts', 'azunta_optimize_category_pin_pre_get_posts' );

/**
 * SQL ORDER BY: pinned posts first, then date.
 *
 * @param string   $orderby Orderby clause.
 * @param WP_Query $query   Query.
 * @return string
 */
function azunta_optimize_category_pin_orderby( string $orderby, WP_Query $query ): string {
	$pinned = $query->get( 'azunta_category_pin_ids' );
	if ( empty( $pinned ) || ! is_array( $pinned ) ) {
		return $orderby;
	}

	global $wpdb;
	$ids = array_values( array_filter( array_map( 'absint', $pinned ) ) );
	if ( empty( $ids ) ) {
		return $orderby;
	}

	$id_list   = implode( ',', $ids );
	$pin_order = "CASE WHEN {$wpdb->posts}.ID IN ({$id_list}) THEN 0 ELSE 1 END ASC, FIELD({$wpdb->posts}.ID, {$id_list})";

	if ( $orderby ) {
		return $pin_order . ', ' . $orderby;
	}

	return $pin_order . ", {$wpdb->posts}.post_date DESC";
}
add_filter( 'posts_orderby', 'azunta_optimize_category_pin_orderby', 10, 2 );

/**
 * Apply pin ordering flag to custom query args for a category.
 *
 * @param int                  $cat_id Category ID.
 * @param array<string, mixed> $args   Base query args.
 * @return array<string, mixed>
 */
function azunta_optimize_apply_category_pin_to_query_args( int $cat_id, array $args ): array {
	$pinned = azunta_optimize_get_category_pinned_post_ids( $cat_id );
	if ( empty( $pinned ) ) {
		return $args;
	}

	$args['azunta_category_pin_ids'] = $pinned;
	$args['ignore_sticky_posts']     = true;

	return $args;
}

/**
 * Echo a small “고정” badge when the current post is pinned in context category.
 *
 * @param int $cat_id Category context (0 = try current category archive).
 */
function azunta_optimize_the_category_pin_badge( int $cat_id = 0 ): void {
	$post_id = get_the_ID();
	if ( ! $post_id ) {
		return;
	}

	if ( $cat_id <= 0 && is_category() ) {
		$cat_id = (int) get_queried_object_id();
	}

	if ( $cat_id <= 0 || ! azunta_optimize_is_post_pinned_in_category( (int) $post_id, $cat_id ) ) {
		return;
	}

	echo '<span class="ao-pin-badge">' . esc_html__( '고정', 'azunta-optimize' ) . '</span>';
}

/**
 * Add body/post class when pinned on a category archive.
 *
 * @param string[] $classes Post classes.
 * @return string[]
 */
function azunta_optimize_category_pin_post_class( array $classes ): array {
	if ( ! is_category() ) {
		return $classes;
	}

	$post_id = get_the_ID();
	$cat_id  = (int) get_queried_object_id();
	if ( $post_id && $cat_id && azunta_optimize_is_post_pinned_in_category( (int) $post_id, $cat_id ) ) {
		$classes[] = 'ao-is-category-pinned';
	}

	return $classes;
}
add_filter( 'post_class', 'azunta_optimize_category_pin_post_class' );
