<?php
/**
 * Lightweight performance tweaks.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_disable_emojis' ) ) {
	/**
	 * Remove emoji scripts/styles from front-end and admin when enabled.
	 */
	function azunta_optimize_disable_emojis(): void {
		if ( ! (bool) get_theme_mod( 'azunta_optimize_disable_emojis', true ) ) {
			return;
		}

		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

		add_filter(
			'tiny_mce_plugins',
			static function ( $plugins ) {
				if ( is_array( $plugins ) ) {
					return array_diff( $plugins, array( 'wpemoji' ) );
				}
				return $plugins;
			}
		);

		add_filter(
			'wp_resource_hints',
			static function ( array $urls, string $relation_type ): array {
				if ( 'dns-prefetch' === $relation_type ) {
					$urls = array_filter(
						$urls,
						static function ( $url ) {
							return is_string( $url ) && false === strpos( $url, 'https://s.w.org/images/core/emoji/' );
						}
					);
				}
				return $urls;
			},
			10,
			2
		);
	}
}
add_action( 'init', 'azunta_optimize_disable_emojis' );

if ( ! function_exists( 'azunta_optimize_disable_wp_embed' ) ) {
	/**
	 * Optionally dequeue wp-embed on the front end.
	 */
	function azunta_optimize_disable_wp_embed(): void {
		if ( ! (bool) get_theme_mod( 'azunta_optimize_disable_wp_embed', false ) ) {
			return;
		}

		wp_deregister_script( 'wp-embed' );
	}
}
add_action( 'wp_footer', 'azunta_optimize_disable_wp_embed' );
