<?php
/**
 * Custom template tags.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_posted_on' ) ) {
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function azunta_optimize_posted_on(): void {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated screen-reader-text" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		printf(
			'<span class="posted-on">%1$s <a href="%2$s" rel="bookmark">%3$s</a></span>',
			esc_html__( '작성일', 'azunta-optimize' ),
			esc_url( get_permalink() ),
			$time_string // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
		);
	}
}

if ( ! function_exists( 'azunta_optimize_posted_by' ) ) {
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function azunta_optimize_posted_by(): void {
		printf(
			'<span class="byline"> %1$s <span class="author vcard"><a class="url fn n" href="%2$s">%3$s</a></span></span>',
			esc_html__( '작성자', 'azunta-optimize' ),
			esc_url( get_author_posts_url( (int) get_the_author_meta( 'ID' ) ) ),
			esc_html( get_the_author() )
		);
	}
}

if ( ! function_exists( 'azunta_optimize_entry_footer' ) ) {
	/**
	 * Prints HTML with meta information for categories, tags and comments.
	 */
	function azunta_optimize_entry_footer(): void {
		if ( 'post' === get_post_type() ) {
			$categories_list = get_the_category_list( esc_html__( ', ', 'azunta-optimize' ) );
			if ( $categories_list ) {
				printf(
					'<span class="cat-links">%1$s %2$s</span>',
					esc_html__( '카테고리:', 'azunta-optimize' ),
					$categories_list // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				);
			}

			$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'azunta-optimize' ) );
			if ( $tags_list ) {
				printf(
					'<span class="tags-links">%1$s %2$s</span>',
					esc_html__( '태그:', 'azunta-optimize' ),
					$tags_list // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				);
			}
		}

		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="comments-link">';
			comments_popup_link(
				sprintf(
					wp_kses(
						/* translators: %s: post title */
						__( '댓글 남기기<span class="screen-reader-text"> — %s</span>', 'azunta-optimize' ),
						array( 'span' => array( 'class' => array() ) )
					),
					wp_kses_post( get_the_title() )
				)
			);
			echo '</span>';
		}

		edit_post_link(
			sprintf(
				wp_kses(
					/* translators: %s: post title */
					__( '편집 <span class="screen-reader-text">%s</span>', 'azunta-optimize' ),
					array( 'span' => array( 'class' => array() ) )
				),
				wp_kses_post( get_the_title() )
			),
			'<span class="edit-link">',
			'</span>'
		);
	}
}

if ( ! function_exists( 'azunta_optimize_post_thumbnail' ) ) {
	/**
	 * Displays an optional post thumbnail.
	 *
	 * @param string $size Image size.
	 */
	function azunta_optimize_post_thumbnail( string $size = 'azunta-optimize-featured' ): void {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() ) :
			?>
			<div class="post-thumbnail">
				<?php the_post_thumbnail( $size, array( 'alt' => the_title_attribute( array( 'echo' => false ) ) ) ); ?>
			</div>
			<?php
		else :
			?>
			<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
				<?php
				the_post_thumbnail(
					$size,
					array(
						'alt' => the_title_attribute( array( 'echo' => false ) ),
					)
				);
				?>
			</a>
			<?php
		endif;
	}
}

if ( ! function_exists( 'azunta_optimize_the_posts_navigation' ) ) {
	/**
	 * Archive pagination.
	 */
	function azunta_optimize_the_posts_navigation(): void {
		the_posts_pagination(
			array(
				'mid_size'  => 2,
				'prev_text' => esc_html__( '이전', 'azunta-optimize' ),
				'next_text' => esc_html__( '다음', 'azunta-optimize' ),
			)
		);
	}
}

if ( ! function_exists( 'azunta_optimize_fallback_menu' ) ) {
	/**
	 * Fallback menu when no primary menu is assigned.
	 */
	function azunta_optimize_fallback_menu(): void {
		echo '<ul id="primary-menu" class="menu">';
		wp_list_pages(
			array(
				'title_li' => '',
				'depth'    => 1,
			)
		);
		echo '</ul>';
	}
}
