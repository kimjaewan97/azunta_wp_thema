<?php
/**
 * Custom template tags.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_posted_on' ) ) {
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function azunta_optimize_posted_on(): void {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated screen-reader-text" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		printf(
			'<span class="posted-on">%1$s <a href="%2$s" rel="bookmark">%3$s</a></span>',
			esc_html__( '작성일', 'azunta-optimize' ),
			esc_url( get_permalink() ),
			$time_string // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
		);
	}
}

if ( ! function_exists( 'azunta_optimize_posted_by' ) ) {
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function azunta_optimize_posted_by(): void {
		printf(
			'<span class="byline"> %1$s <span class="author vcard"><a class="url fn n" href="%2$s">%3$s</a></span></span>',
			esc_html__( '작성자', 'azunta-optimize' ),
			esc_url( get_author_posts_url( (int) get_the_author_meta( 'ID' ) ) ),
			esc_html( get_the_author() )
		);
	}
}

if ( ! function_exists( 'azunta_optimize_entry_footer' ) ) {
	/**
	 * Prints HTML with meta information for categories, tags and comments.
	 */
	function azunta_optimize_entry_footer(): void {
		if ( 'post' === get_post_type() ) {
			$categories_list = get_the_category_list( esc_html__( ', ', 'azunta-optimize' ) );
			if ( $categories_list ) {
				printf(
					'<span class="cat-links">%1$s %2$s</span>',
					esc_html__( '카테고리:', 'azunta-optimize' ),
					$categories_list // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				);
			}

			$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'azunta-optimize' ) );
			if ( $tags_list ) {
				printf(
					'<span class="tags-links">%1$s %2$s</span>',
					esc_html__( '태그:', 'azunta-optimize' ),
					$tags_list // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				);
			}
		}

		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="comments-link">';
			comments_popup_link(
				sprintf(
					wp_kses(
						/* translators: %s: post title */
						__( '댓글 남기기<span class="screen-reader-text"> — %s</span>', 'azunta-optimize' ),
						array( 'span' => array( 'class' => array() ) )
					),
					wp_kses_post( get_the_title() )
				)
			);
			echo '</span>';
		}

		edit_post_link(
			sprintf(
				wp_kses(
					/* translators: %s: post title */
					__( '편집 <span class="screen-reader-text">%s</span>', 'azunta-optimize' ),
					array( 'span' => array( 'class' => array() ) )
				),
				wp_kses_post( get_the_title() )
			),
			'<span class="edit-link">',
			'</span>'
		);
	}
}

if ( ! function_exists( 'azunta_optimize_post_thumbnail' ) ) {
	/**
	 * Displays an optional post thumbnail.
	 *
	 * @param string $size Image size.
	 */
	function azunta_optimize_post_thumbnail( string $size = 'azunta-optimize-featured' ): void {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() ) :
			?>
			<div class="post-thumbnail">
				<?php the_post_thumbnail( $size, array( 'alt' => the_title_attribute( array( 'echo' => false ) ) ) ); ?>
			</div>
			<?php
		else :
			?>
			<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
				<?php
				the_post_thumbnail(
					$size,
					array(
						'alt' => the_title_attribute( array( 'echo' => false ) ),
					)
				);
				?>
			</a>
			<?php
		endif;
	}
}

if ( ! function_exists( 'azunta_optimize_get_primary_category' ) ) {
	/**
	 * Primary (first) category for the current post.
	 *
	 * @return WP_Term|null
	 */
	function azunta_optimize_get_primary_category(): ?WP_Term {
		$categories = get_the_category();
		if ( empty( $categories ) || is_wp_error( $categories ) ) {
			return null;
		}

		return $categories[0];
	}
}

if ( ! function_exists( 'azunta_optimize_get_post_views' ) ) {
	/**
	 * Best-effort post view count (common plugin meta keys).
	 *
	 * @param int|null $post_id Post ID.
	 * @return int|null View count, or null if unavailable.
	 */
	function azunta_optimize_get_post_views( ?int $post_id = null ): ?int {
		$post_id = $post_id ?? get_the_ID();
		if ( ! $post_id ) {
			return null;
		}

		$keys = array(
			'post_views_count',
			'views',
			'_post_views',
			'pvc_views',
			'wpb_post_views_count',
		);

		/**
		 * Filter meta keys used to resolve post view counts.
		 *
		 * @param string[] $keys Meta keys.
		 * @param int      $post_id Post ID.
		 */
		$keys = (array) apply_filters( 'azunta_optimize_post_view_meta_keys', $keys, $post_id );

		foreach ( $keys as $key ) {
			$raw = get_post_meta( $post_id, (string) $key, true );
			if ( '' === $raw || false === $raw ) {
				continue;
			}
			if ( is_numeric( $raw ) ) {
				return max( 0, (int) $raw );
			}
		}

		return null;
	}
}

if ( ! function_exists( 'azunta_optimize_the_card_meta' ) ) {
	/**
	 * Prints meta row for list/card layouts: category, date, views.
	 */
	function azunta_optimize_the_card_meta(): void {
		if ( 'post' !== get_post_type() ) {
			return;
		}

		echo '<div class="post-card__meta entry-meta">';

		$category = azunta_optimize_get_primary_category();
		if ( $category ) {
			$link = get_category_link( $category->term_id );
			printf(
				'<span class="post-card__meta-item post-card__cat"><a href="%1$s" rel="category tag">%2$s</a></span>',
				esc_url( $link ),
				esc_html( $category->name )
			);
		}

		printf(
			'<span class="post-card__meta-item post-card__date"><time class="entry-date published" datetime="%1$s">%2$s</time></span>',
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() )
		);

		$views = azunta_optimize_get_post_views();
		if ( null !== $views ) {
			printf(
				'<span class="post-card__meta-item post-card__views">%1$s %2$s</span>',
				esc_html__( '조회', 'azunta-optimize' ),
				esc_html( number_format_i18n( $views ) )
			);
		}

		if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			$count = (int) get_comments_number();
			if ( $count > 0 ) {
				printf(
					'<span class="post-card__meta-item post-card__comments"><a href="%1$s">%2$s</a></span>',
					esc_url( get_comments_link() ),
					esc_html(
						sprintf(
							/* translators: %s: comment count */
							_n( '댓글 %s', '댓글 %s', $count, 'azunta-optimize' ),
							number_format_i18n( $count )
						)
					)
				);
			}
		}

		echo '</div>';
	}
}

if ( ! function_exists( 'azunta_optimize_the_left_info_box' ) ) {
	/**
	 * Left dark info box for horizontal post cards (thumbnail + badge + CTA feel).
	 *
	 * @param string $size Image size.
	 */
	function azunta_optimize_the_left_info_box( string $size = 'azunta-optimize-card' ): void {
		$category  = azunta_optimize_get_primary_category();
		$has_thumb = has_post_thumbnail() && ! post_password_required();
		$classes   = array( 'left-info-box' );
		$classes[] = $has_thumb ? 'left-info-box--has-image' : 'left-info-box--no-image';
		?>
		<a
			class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
			href="<?php the_permalink(); ?>"
			aria-hidden="true"
			tabindex="-1"
		>
			<?php if ( $has_thumb ) : ?>
				<span class="left-info-box__media">
					<?php
					the_post_thumbnail(
						$size,
						array(
							'alt'      => the_title_attribute( array( 'echo' => false ) ),
							'loading'  => 'lazy',
							'decoding' => 'async',
						)
					);
					?>
				</span>
			<?php endif; ?>

			<span class="left-info-box__overlay" aria-hidden="true"></span>
			<span class="left-info-box__content">
				<?php if ( $category ) : ?>
					<span class="left-info-box__badge"><?php echo esc_html( $category->name ); ?></span>
				<?php else : ?>
					<span class="left-info-box__badge"><?php esc_html_e( 'Blog', 'azunta-optimize' ); ?></span>
				<?php endif; ?>

				<?php if ( ! $has_thumb ) : ?>
					<span class="left-info-box__icon" aria-hidden="true">
						<svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" focusable="false">
							<path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5v-11Z" stroke="currentColor" stroke-width="1.5"/>
							<path d="M8 14.5 10.2 12l2.3 2.5L15 11.5l3 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
							<circle cx="9" cy="9" r="1.25" fill="currentColor"/>
						</svg>
					</span>
				<?php endif; ?>

				<span class="left-info-box__cta">
					<span class="left-info-box__cta-label"><?php esc_html_e( '읽기', 'azunta-optimize' ); ?></span>
					<span class="left-info-box__cta-arrow" aria-hidden="true">→</span>
				</span>
			</span>
		</a>
		<?php
	}
}

if ( ! function_exists( 'azunta_optimize_excerpt_length' ) ) {
	/**
	 * Keep list excerpts short (about 2–3 lines).
	 *
	 * @param int $length Default length.
	 * @return int
	 */
	function azunta_optimize_excerpt_length( int $length ): int {
		if ( is_admin() ) {
			return $length;
		}
		return 28;
	}
}
add_filter( 'excerpt_length', 'azunta_optimize_excerpt_length', 20 );

if ( ! function_exists( 'azunta_optimize_excerpt_more' ) ) {
	/**
	 * Trim trailing "[…]" clutter on excerpts.
	 *
	 * @param string $more Default more string.
	 * @return string
	 */
	function azunta_optimize_excerpt_more( string $more ): string {
		if ( is_admin() ) {
			return $more;
		}
		return '…';
	}
}
add_filter( 'excerpt_more', 'azunta_optimize_excerpt_more' );

if ( ! function_exists( 'azunta_optimize_the_posts_navigation' ) ) {
	/**
	 * Archive pagination.
	 */
	function azunta_optimize_the_posts_navigation(): void {
		the_posts_pagination(
			array(
				'mid_size'  => 2,
				'prev_text' => esc_html__( '이전', 'azunta-optimize' ),
				'next_text' => esc_html__( '다음', 'azunta-optimize' ),
			)
		);
	}
}

if ( ! function_exists( 'azunta_optimize_fallback_menu' ) ) {
	/**
	 * Fallback menu when no primary menu is assigned.
	 */
	function azunta_optimize_fallback_menu(): void {
		echo '<ul id="primary-menu" class="menu">';
		wp_list_pages(
			array(
				'title_li' => '',
				'depth'    => 1,
			)
		);
		echo '</ul>';
	}
}
