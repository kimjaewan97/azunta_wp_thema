<?php
/**
 * Layout helpers and body classes.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_get_sidebar_position' ) ) {
	/**
	 * Get sidebar layout position.
	 *
	 * @return string left|right|none
	 */
	function azunta_optimize_get_sidebar_position(): string {
		$position = (string) get_theme_mod( 'azunta_optimize_sidebar_position', 'right' );
		$allowed  = array( 'left', 'right', 'none' );

		if ( ! in_array( $position, $allowed, true ) ) {
			$position = 'right';
		}

		/**
		 * Filter sidebar position.
		 *
		 * @param string $position Sidebar position.
		 */
		return (string) apply_filters( 'azunta_optimize_sidebar_position', $position );
	}
}

if ( ! function_exists( 'azunta_optimize_has_sidebar' ) ) {
	/**
	 * Whether the current layout should show a sidebar.
	 *
	 * @return bool
	 */
	function azunta_optimize_has_sidebar(): bool {
		return 'none' !== azunta_optimize_get_sidebar_position();
	}
}

if ( ! function_exists( 'azunta_optimize_body_classes' ) ) {
	/**
	 * Add layout-related body classes.
	 *
	 * @param array<int, string> $classes Body classes.
	 * @return array<int, string>
	 */
	function azunta_optimize_body_classes( array $classes ): array {
		$position = azunta_optimize_get_sidebar_position();

		$classes[] = 'ao-theme';
		$classes[] = 'sidebar-' . sanitize_html_class( $position );

		if ( is_singular() ) {
			$classes[] = 'ao-singular';
		}

		if ( azunta_optimize_has_sidebar() && ! azunta_optimize_sidebar_has_content() ) {
			$classes[] = 'sidebar-empty';
		}

		return $classes;
	}
}
add_filter( 'body_class', 'azunta_optimize_body_classes' );
