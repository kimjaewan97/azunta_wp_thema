<?php
/**
 * Simplified comments callback and form defaults.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_comment_callback' ) ) {
	/**
	 * Minimal comment list item: "닉네임 : 댓글 내용"
	 *
	 * @param WP_Comment $comment Comment object.
	 * @param array      $args    wp_list_comments args.
	 * @param int        $depth   Depth.
	 */
	function azunta_optimize_comment_callback( $comment, array $args, int $depth ): void {
		if ( 'div' === $args['style'] ) {
			$tag       = 'div';
			$add_below = 'comment';
		} else {
			$tag       = 'li';
			$add_below = 'div-comment';
		}
		?>
		<<?php echo $tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php comment_class( empty( $args['has_children'] ) ? 'ao-comment-item' : 'parent ao-comment-item', $comment ); ?> id="comment-<?php comment_ID(); ?>">
			<div id="div-comment-<?php comment_ID(); ?>" class="ao-comment">
				<div class="ao-comment__line">
					<span class="ao-comment__author"><?php echo esc_html( get_comment_author( $comment ) ); ?></span>
					<span class="ao-comment__sep" aria-hidden="true"> :</span>
					<span class="ao-comment__text">
						<?php
						if ( '0' === (string) $comment->comment_approved ) {
							echo '<em class="ao-comment__moderation">' . esc_html__( '승인 대기 중입니다.', 'azunta-optimize' ) . '</em> ';
						}
						comment_text( $comment );
						?>
					</span>
				</div>
				<?php
				comment_reply_link(
					array_merge(
						$args,
						array(
							'add_below' => $add_below,
							'depth'     => $depth,
							'max_depth' => $args['max_depth'],
							'reply_text'=> __( '답글', 'azunta-optimize' ),
							'before'    => '<div class="ao-comment__reply">',
							'after'     => '</div>',
						)
					)
				);
				?>
			</div>
		<?php
	}
}

/**
 * Drop website URL field from comment form defaults (extra safety).
 *
 * @param array<string, string> $fields Default fields.
 * @return array<string, string>
 */
function azunta_optimize_comment_form_default_fields( array $fields ): array {
	unset( $fields['url'] );
	return $fields;
}
add_filter( 'comment_form_default_fields', 'azunta_optimize_comment_form_default_fields' );

if ( ! function_exists( 'azunta_optimize_comment_form_args' ) ) {
	/**
	 * Simplified comment form: name, email, comment only.
	 *
	 * @return array<string, mixed>
	 */
	function azunta_optimize_comment_form_args(): array {
		$commenter = wp_get_current_commenter();
		$req       = (bool) get_option( 'require_name_email' );
		$aria_req  = $req ? ' aria-required="true" required' : '';

		$fields = array(
			'author' => sprintf(
				'<p class="comment-form-author"><label for="author">%1$s%2$s</label> <input id="author" name="author" type="text" value="%3$s" size="30" maxlength="245" autocomplete="name"%4$s /></p>',
				esc_html__( '이름', 'azunta-optimize' ),
				$req ? ' <span class="required">*</span>' : '',
				esc_attr( $commenter['comment_author'] ),
				$aria_req
			),
			'email'  => sprintf(
				'<p class="comment-form-email"><label for="email">%1$s%2$s</label> <input id="email" name="email" type="email" value="%3$s" size="30" maxlength="100" autocomplete="email"%4$s /></p>',
				esc_html__( '이메일', 'azunta-optimize' ),
				$req ? ' <span class="required">*</span>' : '',
				esc_attr( $commenter['comment_author_email'] ),
				$aria_req
			),
		);

		return array(
			'title_reply'          => __( '댓글 남기기', 'azunta-optimize' ),
			'title_reply_to'       => __( '%s님에게 답글', 'azunta-optimize' ),
			'cancel_reply_link'    => __( '답글 취소', 'azunta-optimize' ),
			'label_submit'         => __( '댓글 등록', 'azunta-optimize' ),
			'comment_notes_before' => '',
			'comment_notes_after'  => '',
			'fields'               => $fields,
			'comment_field'        => sprintf(
				'<p class="comment-form-comment"><label for="comment">%1$s</label> <textarea id="comment" name="comment" cols="45" rows="5" maxlength="65525" required></textarea></p>',
				esc_html__( '댓글 내용', 'azunta-optimize' )
			),
			'submit_button'        => '<input name="%1$s" type="submit" id="%2$s" class="%3$s" value="%4$s" />',
			'class_submit'         => 'submit ao-comment-submit',
			'logged_in_as'         => '',
			'must_log_in'          => '<p class="must-log-in">' . esc_html__( '댓글을 작성하려면 로그인하세요.', 'azunta-optimize' ) . '</p>',
		);
	}
}
