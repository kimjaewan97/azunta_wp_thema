<?php
/**
 * Scripts and styles.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_scripts' ) ) {
	/**
	 * Enqueue front-end scripts and styles.
	 */
	function azunta_optimize_scripts(): void {
		$main_css     = AZUNTA_OPTIMIZE_DIR . '/assets/css/main.css';
		$homepage_css = AZUNTA_OPTIMIZE_DIR . '/assets/css/homepage.css';
		$nav_js       = AZUNTA_OPTIMIZE_DIR . '/assets/js/navigation.js';
		$sidebar_js   = AZUNTA_OPTIMIZE_DIR . '/assets/js/sidebar.js';

		$style_css = AZUNTA_OPTIMIZE_DIR . '/style.css';

		wp_enqueue_style(
			'azunta-optimize-main',
			AZUNTA_OPTIMIZE_URI . '/assets/css/main.css',
			array(),
			is_readable( $main_css ) ? (string) filemtime( $main_css ) : AZUNTA_OPTIMIZE_VERSION
		);

		// Theme root style.css (custom content highlights, CTA button, etc.).
		wp_enqueue_style(
			'azunta-optimize-style',
			AZUNTA_OPTIMIZE_URI . '/style.css',
			array( 'azunta-optimize-main' ),
			is_readable( $style_css ) ? (string) filemtime( $style_css ) : AZUNTA_OPTIMIZE_VERSION
		);

		// Customizer-driven CSS variables.
		$inline = azunta_optimize_get_dynamic_css();
		if ( $inline ) {
			wp_add_inline_style( 'azunta-optimize-main', $inline );
		}

		if ( is_home() ) {
			wp_enqueue_style(
				'azunta-optimize-homepage',
				AZUNTA_OPTIMIZE_URI . '/assets/css/homepage.css',
				array( 'azunta-optimize-main' ),
				is_readable( $homepage_css ) ? (string) filemtime( $homepage_css ) : AZUNTA_OPTIMIZE_VERSION
			);
		}

		wp_enqueue_script(
			'azunta-optimize-navigation',
			AZUNTA_OPTIMIZE_URI . '/assets/js/navigation.js',
			array(),
			is_readable( $nav_js ) ? (string) filemtime( $nav_js ) : AZUNTA_OPTIMIZE_VERSION,
			true
		);

		wp_enqueue_script(
			'azunta-optimize-sidebar',
			AZUNTA_OPTIMIZE_URI . '/assets/js/sidebar.js',
			array(),
			is_readable( $sidebar_js ) ? (string) filemtime( $sidebar_js ) : AZUNTA_OPTIMIZE_VERSION,
			true
		);

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'azunta_optimize_scripts' );

if ( ! function_exists( 'azunta_optimize_defer_scripts' ) ) {
	/**
	 * Add defer to theme scripts for faster parsing.
	 *
	 * @param string $tag    Script HTML tag.
	 * @param string $handle Script handle.
	 * @param string $src    Script source URL.
	 * @return string
	 */
	function azunta_optimize_defer_scripts( string $tag, string $handle, string $src ): string {
		$defer_handles = array(
			'azunta-optimize-navigation',
			'azunta-optimize-sidebar',
		);

		if ( in_array( $handle, $defer_handles, true ) && false === strpos( $tag, ' defer' ) ) {
			$tag = str_replace( ' src', ' defer src', $tag );
		}

		return $tag;
	}
}
add_filter( 'script_loader_tag', 'azunta_optimize_defer_scripts', 10, 3 );

if ( ! function_exists( 'azunta_optimize_get_dynamic_css' ) ) {
	/**
	 * Build inline CSS from Customizer layout settings.
	 *
	 * @return string
	 */
	function azunta_optimize_get_dynamic_css(): string {
		$container = absint( get_theme_mod( 'azunta_optimize_container_width', 1200 ) );
		$content   = absint( get_theme_mod( 'azunta_optimize_content_width_no_sidebar', 800 ) );

		if ( $container < 960 ) {
			$container = 960;
		}
		if ( $container > 1400 ) {
			$container = 1400;
		}
		if ( $content < 600 ) {
			$content = 600;
		}
		if ( $content > 1200 ) {
			$content = 1200;
		}

		$css  = ':root{';
		$css .= '--ao-container:' . $container . 'px;';
		$css .= '--ao-content-narrow:' . $content . 'px;';
		$css .= '}';

		return $css;
	}
}
