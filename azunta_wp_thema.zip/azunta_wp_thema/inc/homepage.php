<?php
/**
 * Homepage helpers: queries, category choices, accordion markup.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize a category ID from Customizer (0 = none).
 *
 * @param mixed $value Raw value.
 * @return int
 */
function azunta_optimize_sanitize_category_id( $value ): int {
	$id = absint( $value );
	if ( $id <= 0 ) {
		return 0;
	}
	$term = get_term( $id, 'category' );
	if ( ! $term || is_wp_error( $term ) ) {
		return 0;
	}
	return $id;
}

/**
 * Category choices for Customizer select controls.
 *
 * @return array<int|string, string>
 */
function azunta_optimize_get_category_choices(): array {
	$choices = array(
		0 => __( '— 카테고리 선택 —', 'azunta-optimize' ),
	);

	$categories = get_categories(
		array(
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		)
	);

	if ( empty( $categories ) || is_wp_error( $categories ) ) {
		return $choices;
	}

	foreach ( $categories as $category ) {
		$choices[ (int) $category->term_id ] = $category->name;
	}

	return $choices;
}

/**
 * Latest posts query for homepage.
 *
 * @return WP_Query
 */
function azunta_optimize_get_home_latest_query(): WP_Query {
	$count = absint( get_theme_mod( 'azunta_optimize_home_latest_count', 10 ) );
	if ( $count < 1 ) {
		$count = 10;
	}
	if ( $count > 30 ) {
		$count = 30;
	}

	/**
	 * Filter latest posts query args.
	 *
	 * @param array<string, mixed> $args Query args.
	 */
	$args = (array) apply_filters(
		'azunta_optimize_home_latest_query_args',
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $count,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);

	return new WP_Query( $args );
}

/**
 * Category posts query for homepage columns.
 *
 * @param int $cat_id Category term ID.
 * @param int $count  Number of posts.
 * @return WP_Query
 */
function azunta_optimize_get_home_category_query( int $cat_id, int $count = 5 ): WP_Query {
	if ( $count < 1 ) {
		$count = 5;
	}
	if ( $count > 20 ) {
		$count = 20;
	}

	/**
	 * Filter category column query args.
	 *
	 * @param array<string, mixed> $args   Query args.
	 * @param int                  $cat_id Category ID.
	 */
	$args = (array) apply_filters(
		'azunta_optimize_home_category_query_args',
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $count,
			'cat'                 => $cat_id,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		),
		$cat_id
	);

	return new WP_Query( $args );
}

/**
 * URL for “more” on the latest posts section.
 *
 * @return string
 */
function azunta_optimize_get_blog_more_url(): string {
	$page_for_posts = (int) get_option( 'page_for_posts' );
	if ( $page_for_posts > 0 ) {
		$url = get_permalink( $page_for_posts );
		if ( is_string( $url ) && $url ) {
			return $url;
		}
	}

	$archive = get_post_type_archive_link( 'post' );
	if ( is_string( $archive ) && $archive ) {
		return $archive;
	}

	return home_url( '/' );
}

/**
 * Whether the theme-controlled sidebar has any content to show.
 *
 * @return bool
 */
function azunta_optimize_sidebar_has_content(): bool {
	if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_search', true ) ) {
		return true;
	}
	if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_categories', true ) ) {
		return true;
	}
	if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_recent_posts', false ) ) {
		return true;
	}
	if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_recent_comments', false ) ) {
		return true;
	}
	if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_archives', false ) ) {
		return true;
	}
	if ( (bool) get_theme_mod( 'azunta_optimize_sidebar_show_widgets', false ) && is_active_sidebar( 'sidebar-1' ) ) {
		return true;
	}
	if ( function_exists( 'azunta_optimize_should_show_ads' ) && azunta_optimize_should_show_ads( 'sidebar' ) ) {
		return true;
	}

	return false;
}

/**
 * Render hierarchical category list with accordion toggles.
 *
 * @param int $parent Parent term ID.
 * @return void
 */
function azunta_optimize_list_categories_accordion( int $parent = 0 ): void {
	$terms = get_terms(
		array(
			'taxonomy'   => 'category',
			'hide_empty' => true,
			'parent'     => $parent,
			'orderby'    => 'name',
			'order'      => 'ASC',
		)
	);

	if ( empty( $terms ) || is_wp_error( $terms ) ) {
		if ( 0 === $parent ) {
			echo '<p class="ao-cat-empty">' . esc_html__( '카테고리가 없습니다.', 'azunta-optimize' ) . '</p>';
		}
		return;
	}

	$ul_class = 0 === $parent ? 'ao-cat-list' : 'children';
	$ul_id    = 0 === $parent ? '' : 'ao-cat-children-' . $parent;

	printf(
		'<ul class="%1$s"%2$s%3$s>',
		esc_attr( $ul_class ),
		$ul_id ? ' id="' . esc_attr( $ul_id ) . '"' : '',
		0 === $parent ? '' : ' hidden'
	);

	foreach ( $terms as $term ) {
		$children = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => true,
				'parent'     => (int) $term->term_id,
				'number'     => 1,
				'fields'     => 'ids',
			)
		);
		$has_children = ! empty( $children ) && ! is_wp_error( $children );
		$link         = get_term_link( $term );
		if ( is_wp_error( $link ) ) {
			continue;
		}

		$li_class = 'cat-item cat-item-' . (int) $term->term_id;
		if ( $has_children ) {
			$li_class .= ' cat-item-has-children';
		}

		echo '<li class="' . esc_attr( $li_class ) . '">';

		if ( $has_children ) {
			$panel_id = 'ao-cat-children-' . (int) $term->term_id;
			echo '<div class="ao-cat-row">';
			printf(
				'<a href="%1$s">%2$s</a>',
				esc_url( $link ),
				esc_html( $term->name )
			);
			printf(
				'<button type="button" class="ao-cat-toggle" aria-expanded="false" aria-controls="%1$s"><span class="screen-reader-text">%2$s</span></button>',
				esc_attr( $panel_id ),
				/* translators: %s: category name */
				esc_html( sprintf( __( '%s 하위 카테고리 펼치기/접기', 'azunta-optimize' ), $term->name ) )
			);
			echo '</div>';
			azunta_optimize_list_categories_accordion( (int) $term->term_id );
		} else {
			printf(
				'<a href="%1$s">%2$s</a>',
				esc_url( $link ),
				esc_html( $term->name )
			);
		}

		echo '</li>';
	}

	echo '</ul>';
}
