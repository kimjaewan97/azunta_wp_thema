<?php
/**
 * Widget areas.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_widgets_init' ) ) {
	/**
	 * Register widget areas.
	 */
	function azunta_optimize_widgets_init(): void {
		register_sidebar(
			array(
				'name'          => esc_html__( 'Header', 'azunta-optimize' ),
				'id'            => 'header-1',
				'description'   => esc_html__( 'Widgets below the site branding / navigation.', 'azunta-optimize' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Primary Sidebar', 'azunta-optimize' ),
				'id'            => 'sidebar-1',
				'description'   => esc_html__( 'Optional widgets. Enable “Show widget area” under Azunta Optimize → Sidebar. Theme search/categories render separately.', 'azunta-optimize' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		$footer_columns = array(
			'footer-1' => esc_html__( 'Footer Column 1', 'azunta-optimize' ),
			'footer-2' => esc_html__( 'Footer Column 2', 'azunta-optimize' ),
			'footer-3' => esc_html__( 'Footer Column 3', 'azunta-optimize' ),
		);

		foreach ( $footer_columns as $id => $name ) {
			register_sidebar(
				array(
					'name'          => $name,
					'id'            => $id,
					'description'   => esc_html__( 'Footer widget column.', 'azunta-optimize' ),
					'before_widget' => '<section id="%1$s" class="widget %2$s">',
					'after_widget'  => '</section>',
					'before_title'  => '<h2 class="widget-title">',
					'after_title'   => '</h2>',
				)
			);
		}
	}
}
add_action( 'widgets_init', 'azunta_optimize_widgets_init' );
