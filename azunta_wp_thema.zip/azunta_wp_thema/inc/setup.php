<?php
/**
 * Theme setup.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'azunta_optimize_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 */
	function azunta_optimize_setup(): void {
		load_theme_textdomain( 'azunta-optimize', AZUNTA_OPTIMIZE_DIR . '/languages' );

		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 80,
				'width'       => 240,
				'flex-height' => true,
				'flex-width'  => true,
			)
		);
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_theme_support( 'align-wide' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'assets/css/editor-style.css' );

		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary Menu', 'azunta-optimize' ),
				'footer'  => esc_html__( 'Footer Menu', 'azunta-optimize' ),
			)
		);

		add_image_size( 'azunta-optimize-featured', 1200, 630, false );
	}
}
add_action( 'after_setup_theme', 'azunta_optimize_setup' );

if ( ! function_exists( 'azunta_optimize_content_width' ) ) {
	/**
	 * Set the content width in pixels, based on the theme's design.
	 *
	 * Priority 0 to make it available to lower priority callbacks.
	 *
	 * @global int $content_width
	 */
	function azunta_optimize_content_width(): void {
		$width = (int) get_theme_mod( 'azunta_optimize_container_width', 1200 );
		$GLOBALS['content_width'] = absint( apply_filters( 'azunta_optimize_content_width', $width ) );
	}
}
add_action( 'after_setup_theme', 'azunta_optimize_content_width', 0 );
