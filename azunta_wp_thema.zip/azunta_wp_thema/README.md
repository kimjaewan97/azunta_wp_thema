# Azunta WP Theme

나만의 커스텀 워드프레스 테마입니다.

## 홈페이지 레이아웃 (v1.4)

1. **카테고리 박스** — 홈 상단에 카테고리 카드 그리드
2. **최신 글** — 그 아래 최신 글 목록
3. **카테고리 칼럼** (선택) — 커스터마이저에서 좌/우 카테고리 지정 시

설정: **외모 → 사용자 정의하기 → Azunta Optimize → Homepage**

## 카테고리 상단 고정

글 편집 화면 오른쪽 **「카테고리 상단 고정」** 박스에서, 글이 속한 카테고리를 체크하면 해당 카테고리 목록 맨 위에 고정됩니다. 카테고리 아카이브와 홈의 카테고리 칼럼에 모두 적용됩니다.

## 다운로드 및 설치 방법

1. **이 페이지에서 ZIP 다운로드**
   - 오른쪽 위 **Code** 버튼 → **Download ZIP** 클릭

2. **워드프레스에 설치**
   - 워드프레스 관리자 → **외모 → 테마 → 테마 추가 → 테마 업로드**
   - 다운로드한 `azunta_wp_thema-main.zip` 파일을 선택해서 업로드
   - 테마를 활성화하세요.

## 주의사항
- 다운로드 후 압축을 풀지 말고 **그대로 업로드**하세요.
- 테마 폴더명은 `azunta_wp_thema` 입니다.

## 스크린샷
<img width="163" height="388" alt="Bildschirmfoto 2026-07-16 um 23 02 09" src="https://github.com/user-attachments/assets/486b36ee-7a0b-4dd6-aac7-e1fab1b4f12b" />
<br><br>
<img width="439" height="151" alt="Bildschirmfoto 2026-07-16 um 23 02 19" src="https://github.com/user-attachments/assets/4a1f439e-7c38-4471-8cad-4b8fd11a95a0" />
<br><br>
<img width="679" height="152" alt="Bildschirmfoto 2026-07-16 um 23 02 27" src="https://github.com/user-attachments/assets/661333ec-cc70-4122-b3e8-def1999c08e7" />
