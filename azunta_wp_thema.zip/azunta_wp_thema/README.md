# Azunta Optimize

가볍고 빠른 범용 워드프레스 블로그 테마입니다. GeneratePress 스타일의 미니멀 구조에 **AdSense 수익 극대화**를 위한 광고 슬롯을 Customizer로 제어합니다.

- **Theme slug / text domain:** `azunta-optimize`
- **Version:** 1.2.0
- **Requires:** WordPress 6.0+, PHP 8.0+
- **License:** GPL v2 or later

---

## 특징

| 영역 | 내용 |
|------|------|
| 홈페이지 | 최신 글 섹션 + 카테고리 2단 (Customizer로 카테고리 선택) |
| 싱글 포스트 | 날짜/작성자 ON·OFF, After Title 광고 강조, 단순 댓글 |
| 사이드바 | 검색(인셋 pill) + 계층 카테고리 아코디언 |
| 언어 | 방문자용 UI 문자열 한국어 (translation-ready 유지) |
| 디자인 | 둥근 카드(8–12px), soft shadow, hover |
| 광고 | 8개 슬롯, 싱글 본문 제목 아래·중간·끝 배치 |
| 유지보수 | `inc/*` + `template-parts`, child-theme friendly |

---

## 설치

1. `azunta-optimize` 폴더를 `wp-content/themes/` 에 업로드 (또는 zip으로 테마 설치)
2. **외모 → 테마**에서 **Azunta Optimize** 활성화
3. **외모 → 메뉴**에서 Primary / Footer 메뉴 지정
4. **외모 → 사용자 정의하기 → Azunta Optimize** 에서 Homepage·Sidebar·Layout·Ads 설정
5. (선택) Header / Footer 위젯, 또는 Sidebar 위젯 영역 활성화

### 권장 초기 설정

1. **Layout** → 사이드바 위치 `Right`, 컨테이너 `1200`
2. **Homepage** → Category Left / Right 선택 (예: 유학, 독일 생활)
3. **Single Post** → 날짜/작성자 표시는 기본 OFF (필요 시 ON)
4. **Sidebar** → 검색·카테고리 유지, 나머지 OFF
5. **Ads / AdSense** → Publisher ID + **After Title / In-content / End** 코드
6. 미리보기: **Show ads to logged-in users** 잠시 ON

---

## 싱글 포스트 (v1.2)

### 표시 순서

```
[ H1 제목 ]
[ 작성일·작성자 ]     ← Customizer ON일 때만 (기본 숨김)
★ After Title Ad     ← 제목 직후, 대표 이미지 전  (가장 중요)
[ 대표 이미지 ]
[ 문단 1 ]
[ 문단 2 ]
★ In-Content Ad (2)  ← 2번째 문단 뒤
[ 문단 3–4 ]
[ 문단 5 ]
★ In-Content Ad (5)  ← 5번째 문단 뒤 (긴 글 권장)
[ 나머지 본문 ]
★ End of Content Ad  ← 본문 맨 끝
[ 카테고리 / 태그 ]
[ 이전 글 / 다음 글 ]
[ 댓글 ]
```

### Customizer — Single Post

경로: **Azunta Optimize → Single Post**

| 옵션 | 기본 | 설명 |
|------|------|------|
| Show date and author on single posts | **OFF** | 켜면 제목 아래 “작성일 … 작성자 …” 표시 |

### 싱글에서 AdSense 활용 가이드

수익·가독성 균형에 효과적인 순서:

| 우선순위 | 슬롯 | Customizer 이름 | 언제 켜나 |
|----------|------|-----------------|-----------|
| 1 | `after_title` | After Title Ad | **거의 항상** — 제목 바로 아래 시선 집중 |
| 2 | `end_content` | End of Content Ad | **거의 항상** — 본문 읽은 직후 |
| 3 | `in_content_2` | In-Content (2nd p) | 본문 문단 3개 이상일 때 |
| 4 | `in_content_5` | In-Content (5th p) | 긴 글(5문단+)일 때 |
| 5 | `sidebar` | Sidebar Ad | 사이드바 레이아웃 사용 시 |

**설정 팁**

1. Ads → Publisher ID 입력 + Auto-load script ON  
2. 각 슬롯 **Enable** 체크 후 AdSense **반응형** 단위 코드 붙여넣기  
3. 로그인 상태로 미리보려면 **Show ads to logged-in users** ON  
4. 짧은 글은 In-content 5를 끄거나, minimum paragraphs를 조정  
5. 제목 아래 광고는 썸네일 **앞**에 나가므로 클릭·노출이 유리합니다  

After Title 영역은 카드형 배경(`.ao-ad--after-title`)으로 구분되어 배치 확인이 쉽습니다.

### 댓글 (단순화)

- 목록: **`닉네임 : 댓글 내용`** 한 줄 스타일  
- 제거: 아바타, 날짜, “says”, Edit 링크  
- 유지: 대댓글(답글 링크 “답글”)  
- 폼 필드: **이름, 이메일, 댓글 내용**만  

---

## 홈페이지 구조 (`home.php`)

블로그 글 목록(설정 → 읽기: **최신 글** 이 홈이거나 **글 페이지**로 지정된 페이지)에서 사용됩니다.

```
┌─ content-area ─────────────────────────────┬─ sidebar ──────┐
│  [최신 글]                      [더보기 →]  │  ★ SIDEBAR AD  │
│  ┌ 카드 ┐ 최신 N개 (기본 10) 세로 나열      │  검색          │
│  └──────┘                                  │  카테고리 ▾    │
│                                            │  (아코디언)    │
│  ┌── 왼쪽 카테고리 ──┬── 오른쪽 카테고리 ──┐ │                │
│  │ 제목 + 더보기     │ 제목 + 더보기       │ │                │
│  │ 최근 글 5개       │ 최근 글 5개         │ │                │
│  └──────────────────┴────────────────────┘ │                │
└────────────────────────────────────────────┴────────────────┘
```

- 모바일: 카테고리 2단 → 1열 스택
- 카테고리 미선택(0) 시 해당 컬럼 숨김, 둘 다 없으면 2단 영역 전체 숨김
- 최신 글 루프에 **Archive Between** 광고 슬롯 적용 가능

### Customizer — Homepage

경로: **외모 → 사용자 정의하기 → Azunta Optimize → Homepage**

| 옵션 | 설명 | 기본 |
|------|------|------|
| Latest posts section title | 최신 글 섹션 제목 | 최신 글 |
| Latest posts count | 최신 글 개수 (1–30) | 10 |
| **Category Left** | 왼쪽 컬럼 카테고리 | (미선택) |
| Category Left title | 제목 오버라이드 (비우면 카테고리명) | (빈 값) |
| **Category Right** | 오른쪽 컬럼 카테고리 | (미선택) |
| Category Right title | 제목 오버라이드 | (빈 값) |
| Posts per category column | 컬럼당 글 수 | 5 |

“더보기” 링크:

- 최신 글 → 글 페이지 URL 또는 홈 / 포스트 아카이브
- 카테고리 컬럼 → 해당 카테고리 아카이브

---

## 사이드바

테마가 **기본 블록**을 직접 출력합니다. WordPress 기본 위젯(Recent Posts 등)에 의존하지 않습니다.

### 기본 ON

| 블록 | 설명 |
|------|------|
| 검색 | 인셋 pill 스타일, placeholder **「검색어를 입력하세요」** |
| 카테고리 | 계층 구조 + **아코디언** (하위 카테고리 접기/펼치기) |

### 기본 OFF (Customizer에서 켤 수 있음)

- Recent Posts  
- Recent Comments  
- Archives  
- Widget area (`sidebar-1`) — **Appearance → Widgets** 추가 위젯

경로: **Azunta Optimize → Sidebar**

### 카테고리 아코디언

- 상위 카테고리 옆 **토글 버튼** 클릭 시 하위 목록 표시
- `aria-expanded` / `aria-controls` 접근성 지원
- 기본 상태: **접힘**
- 스크립트: `assets/js/sidebar.js` (defer)

---

## 디자인 노트

- CSS 변수: `--ao-radius` 10px, `--ao-radius-lg` 12px, soft `--ao-shadow` / hover
- 포스트 카드(`.ao-card`), 사이드바 블록, 검색 pill, 썸네일 둥글게
- 검색: input 안쪽에 버튼이 붙은 인셋 형태 (`.search-form--inset`)
- 홈 전용: `assets/css/homepage.css`
- 방문자 UI 문자열: 한국어 (text domain `azunta-optimize` 유지 → 번역 가능)

---

## 광고 영역 맵 (전체)

페이지 구조와 슬롯 위치:

```
┌────────────────────────────────────────────┐
│  HEADER (로고 + 메뉴 + Header 위젯)         │
├────────────────────────────────────────────┤
│  ★ HEADER AD  (리더보드 / 반응형)           │
├──────────────────────────┬─────────────────┤
│  글 제목 (H1)            │                 │
│  ★ AFTER TITLE AD        │  ★ SIDEBAR AD   │
│  대표 이미지              │  사이드바 위젯    │
│  문단 1                  │                 │
│  문단 2                  │                 │
│  ★ IN-CONTENT AD (2)     │                 │
│  문단 3 … 4              │                 │
│  문단 5                  │                 │
│  ★ IN-CONTENT AD (5)     │                 │
│  나머지 본문              │                 │
│  ★ END OF CONTENT AD     │                 │
│  카테고리/태그 · 댓글     │                 │
├──────────────────────────┴─────────────────┤
│  ★ FOOTER AD                               │
│  Footer 위젯 3열 + 저작권                   │
└────────────────────────────────────────────┘
```

### 아카이브 / 블로그 인덱스

```
[ 포스트 카드 1 ]
[ 포스트 카드 2 ]
[ 포스트 카드 3 ]
★ ARCHIVE BETWEEN AD   ← 기본: 매 3번째 글 뒤
[ 포스트 카드 4 ]
...
```

간격은 Customizer **Archive: show ad every N posts** 로 변경 (기본 `3`).

---

## Customizer — Ads / AdSense

경로: **외모 → 사용자 정의하기 → Azunta Optimize → Ads / AdSense**

### 전역 옵션

| 옵션 | 설명 | 기본값 |
|------|------|--------|
| Enable ads site-wide | 모든 광고 마스터 스위치 | ON |
| Show ads to logged-in users | 로그인 사용자에게도 표시 | OFF |
| AdSense Publisher ID | `ca-pub-XXXXXXXX` | (빈 값) |
| Auto-load AdSense script | head에 adsbygoogle.js 1회 로드 | ON |
| Archive: every N posts | 목록 사이 광고 간격 | 3 |
| In-content: minimum paragraphs | 이 문단 수 미만이면 본문 중간 광고 스킵 | 3 |

### 슬롯별 옵션

각 슬롯마다:

1. **Enable: {슬롯 이름}** — 체크 시 활성화  
2. **Code: {슬롯 이름}** — AdSense 단위 HTML 붙여넣기  

| 슬롯 키 | 표시 이름 | 위치 |
|---------|-----------|------|
| `header` | Header Ad | 헤더 바로 아래 |
| `after_title` | After Title Ad | 제목 바로 아래 (single/page) |
| `in_content_2` | In-Content (2nd p) | 본문 2번째 `</p>` 뒤 |
| `in_content_5` | In-Content (5th p) | 본문 5번째 `</p>` 뒤 |
| `end_content` | End of Content Ad | 본문 맨 끝 |
| `sidebar` | Sidebar Ad | 사이드바 최상단 |
| `footer` | Footer Ad | 푸터 위젯 위 |
| `archive_between` | Archive Between Posts | 루프 포스트 사이 |

슬롯이 켜져 있어도 **코드가 비어 있으면 출력하지 않습니다.**

---

## In-Content 삽입 규칙

- `the_content` 필터 (priority `12`) 사용
- 닫는 태그 `</p>` 기준으로만 삽입 → **리스트, 이미지, 인용, 갤러리 내부가 깨지지 않음**
- 기본 위치: **2번째 문단 후**, **5번째 문단 후**
- 문단 수가 `minimum paragraphs` 미만이면 중간 광고 전체 스킵
- 해당 위치 슬롯이 OFF이거나 코드 없으면 그 위치만 스킵
- 기본 적용 포스트 타입: `post` (페이지 포함 시 필터로 확장 가능)
- 피드, REST, 비밀번호 보호 글, 관리자 화면에서는 미삽입

### 반응형 단위 예시

Publisher ID로 스크립트를 자동 로드하는 경우, 단위 코드만 붙여넣으면 됩니다:

```html
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="1234567890"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
```

단위 코드에 이미 `adsbygoogle.js` `<script src=…>` 가 포함되어 있다면  
**Auto-load AdSense script** 를 끄거나, 중복 스크립트 태그를 제거하세요.

---

## Layout 설정

**Azunta Optimize → Layout**

| 옵션 | 설명 | 기본 |
|------|------|------|
| Container width | 전체 컨테이너 최대 너비 (960–1400px) | 1200 |
| Sidebar position | Right / Left / None | Right |
| Content max-width without sidebar | 사이드바 없을 때 본문 가독성 폭 | 800 |

CSS 변수로 주입됩니다:

- `--ao-container`
- `--ao-content-narrow`

---

## 위젯 영역

| ID | 이름 | 용도 |
|----|------|------|
| `header-1` | Header | 헤더 하단 |
| `sidebar-1` | Primary Sidebar | Customizer **Show widget area** ON일 때만 테마 블록 아래에 출력 |
| `footer-1` | Footer Column 1 | 푸터 1열 |
| `footer-2` | Footer Column 2 | 푸터 2열 |
| `footer-3` | Footer Column 3 | 푸터 3열 |

> 사이드바 검색·카테고리는 위젯이 아니라 **테마 고정 블록**입니다.

---

## Performance

**Azunta Optimize → Performance**

| 옵션 | 기본 | 설명 |
|------|------|------|
| Disable WordPress emoji scripts | ON | 프론트/어드민 이모지 스크립트 제거 |
| Disable wp-embed script | OFF | 다른 사이트 임베드에 영향 가능 — 신중히 |

테마 JS(`navigation.js`)는 `defer` 로 로드됩니다.

---

## 파일 구조

```
azunta-optimize/
├── style.css                 # 테마 헤더
├── functions.php             # 모듈 로드
├── home.php                  # 홈: 최신 글 + 카테고리 2단
├── header.php / footer.php
├── index.php / single.php / page.php
├── archive.php / search.php / 404.php
├── sidebar.php / comments.php / searchform.php
├── assets/
│   ├── css/main.css
│   ├── css/homepage.css      # 홈 전용
│   ├── css/editor-style.css
│   ├── js/navigation.js
│   └── js/sidebar.js         # 카테고리 아코디언
├── inc/
│   ├── setup.php
│   ├── enqueue.php
│   ├── layout.php
│   ├── widgets.php
│   ├── template-tags.php
│   ├── comments.php          # 단순 댓글 콜백·폼
│   ├── performance.php
│   ├── ads.php
│   ├── homepage.php
│   └── customizer.php
└── template-parts/
    ├── home/
    ├── header/site-branding.php
    ├── navigation/primary.php
    ├── content/              # content-single.php 등
    ├── ads/slot.php
    └── footer/widgets.php
```

---

## 변경 이력 (요약)

### v1.2.0
- 싱글: 날짜/작성자 Customizer ON/OFF (기본 OFF)
- After Title 광고 영역 시각 강조
- 댓글: `닉네임 : 내용` 미니멀 UI, 폼 단순화
- 검색: 인셋 pill + 한국어 placeholder
- 프론트 UI 한국어화
- README 싱글 AdSense 가이드

### v1.1.0
- 홈페이지 섹션 레이아웃, 사이드바 아코디언, 카드 UI

---

## Child Theme 예시

```css
/*
Theme Name: Azunta Optimize Child
Template: azunta-optimize
Text Domain: azunta-optimize-child
*/
```

```php
<?php
// functions.php
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'azunta-optimize-child',
		get_stylesheet_uri(),
		array( 'azunta-optimize-main' ),
		wp_get_theme()->get( 'Version' )
	);
}, 20 );
```

템플릿 오버라이드: 차일드에 `template-parts/content/content-single.php` 등을 같은 경로로 복사 후 수정.

---

## 개발자 훅 / 필터

| 필터 | 설명 |
|------|------|
| `azunta_optimize_should_show_ads` | `(bool $show, string $slot)` 광고 표시 여부 |
| `azunta_optimize_ad_html` | `(string $code, string $slot)` 출력 전 HTML |
| `azunta_optimize_in_content_positions` | `(array $map)` 문단번호 => 슬롯키, 기본 `[2=>'in_content_2', 5=>'in_content_5']` |
| `azunta_optimize_in_content_post_types` | 본문 중간 광고 적용 포스트 타입, 기본 `['post']` |
| `azunta_optimize_sidebar_position` | 사이드바 위치 필터 |
| `azunta_optimize_content_width` | `$content_width` 필터 |
| `azunta_optimize_home_latest_query_args` | 홈 최신 글 `WP_Query` args |
| `azunta_optimize_home_category_query_args` | 홈 카테고리 컬럼 query args |

### 페이지에도 in-content 광고 적용 예시

```php
add_filter( 'azunta_optimize_in_content_post_types', function ( $types ) {
	$types[] = 'page';
	return $types;
} );
```

### 특정 카테고리에서 광고 끄기

```php
add_filter( 'azunta_optimize_should_show_ads', function ( $show, $slot ) {
	if ( is_category( 'no-ads' ) ) {
		return false;
	}
	return $show;
}, 10, 2 );
```

---

## AdSense 정책 안내 (요약)

테마는 배치 도구일 뿐이며, **Google AdSense 정책 준수는 사이트 운영자 책임**입니다.

- 가치 있는 원본 콘텐츠 비율 유지 (광고만 가득한 페이지 지양)
- 클릭 유도 문구·화살표·가짜 UI 금지
- 모바일에서 콘텐츠를 가리는 과한 전면 광고 주의
- 금지 콘텐츠 카테고리 준수
- 테스트 시 자신의 광고를 반복 클릭하지 말 것

자세한 내용은 [AdSense 프로그램 정책](https://support.google.com/adsense/answer/48182)을 확인하세요.

---

## 라이선스

GNU General Public License v2 or later.  
WordPress와 동일하게 자유 수정·재배포 가능합니다.
