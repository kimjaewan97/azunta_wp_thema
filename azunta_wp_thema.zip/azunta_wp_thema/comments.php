<?php
/**
 * Simplified comments template.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area ao-comments">
	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$azunta_optimize_count = (int) get_comments_number();
			printf(
				/* translators: %s: number of comments */
				esc_html( _n( '댓글 %s개', '댓글 %s개', $azunta_optimize_count, 'azunta-optimize' ) ),
				esc_html( number_format_i18n( $azunta_optimize_count ) )
			);
			?>
		</h2>

		<ol class="comment-list ao-comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 0,
					'callback'    => 'azunta_optimize_comment_callback',
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation(
			array(
				'prev_text' => esc_html__( '이전 댓글', 'azunta-optimize' ),
				'next_text' => esc_html__( '다음 댓글', 'azunta-optimize' ),
			)
		);

		if ( ! comments_open() ) :
			?>
			<p class="no-comments"><?php esc_html_e( '댓글이 닫혀 있습니다.', 'azunta-optimize' ); ?></p>
			<?php
		endif;
	endif;

	comment_form( azunta_optimize_comment_form_args() );
	?>
</div>
