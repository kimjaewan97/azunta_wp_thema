<?php
/**
 * Page template.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

get_header();
?>

<main id="primary" class="site-main">
	<div class="ao-container ao-layout">
		<div class="content-area">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content', 'page' );

				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
			endwhile;
			?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</main>

<?php
get_footer();
