<?php
/**
 * Archive template.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

get_header();
?>

<main id="primary" class="site-main">
	<div class="ao-container ao-layout">
		<div class="content-area">
			<?php if ( have_posts() ) : ?>

				<header class="page-header">
					<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="archive-description">', '</div>' );
					?>
				</header>

				<div class="posts-list">
					<?php
					$ao_index = 0;
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content/content', get_post_type() );

						if ( function_exists( 'azunta_optimize_should_show_archive_ad' ) && azunta_optimize_should_show_archive_ad( $ao_index ) ) {
							azunta_optimize_ad( 'archive_between' );
						}
						++$ao_index;
					endwhile;
					?>
				</div>

				<?php azunta_optimize_the_posts_navigation(); ?>

			<?php else : ?>

				<?php get_template_part( 'template-parts/content/content', 'none' ); ?>

			<?php endif; ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</main>

<?php
get_footer();
