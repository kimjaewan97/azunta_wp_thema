/**
 * Sidebar category accordion: expand/collapse children.
 */
(function () {
	'use strict';

	var root = document.querySelector('.ao-cat-accordion');
	if (!root) {
		return;
	}

	root.addEventListener('click', function (event) {
		var button = event.target.closest('.ao-cat-toggle');
		if (!button || !root.contains(button)) {
			return;
		}

		var panelId = button.getAttribute('aria-controls');
		if (!panelId) {
			return;
		}

		var panel = document.getElementById(panelId);
		if (!panel) {
			return;
		}

		var expanded = button.getAttribute('aria-expanded') === 'true';
		button.setAttribute('aria-expanded', expanded ? 'false' : 'true');

		if (expanded) {
			panel.setAttribute('hidden', '');
			panel.classList.remove('is-open');
		} else {
			panel.removeAttribute('hidden');
			panel.classList.add('is-open');
		}
	});
})();
