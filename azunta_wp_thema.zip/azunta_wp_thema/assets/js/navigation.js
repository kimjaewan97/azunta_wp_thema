/**
 * Mobile navigation: hamburger toggle, ARIA, Escape to close.
 */
(function () {
	'use strict';

	var toggle = document.querySelector('.menu-toggle');
	var nav = document.getElementById('site-navigation');

	if (!toggle || !nav) {
		return;
	}

	function setOpen(isOpen) {
		toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		nav.classList.toggle('toggled', isOpen);
	}

	function isOpen() {
		return toggle.getAttribute('aria-expanded') === 'true';
	}

	toggle.addEventListener('click', function () {
		setOpen(!isOpen());
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && isOpen()) {
			setOpen(false);
			toggle.focus();
		}
	});

	// Close menu when focus leaves navigation on small screens.
	document.addEventListener('click', function (event) {
		if (!isOpen()) {
			return;
		}
		if (!nav.contains(event.target) && !toggle.contains(event.target)) {
			setOpen(false);
		}
	});
})();
