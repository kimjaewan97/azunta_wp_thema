<?php
/**
 * Ad slot wrapper.
 *
 * @package Azunta_Optimize
 *
 * @var array $args {
 *     @type string $slot  Slot key.
 *     @type string $code  Sanitized ad HTML.
 *     @type string $label Human-readable label.
 * }
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$slot  = isset( $args['slot'] ) ? (string) $args['slot'] : '';
$code  = isset( $args['code'] ) ? (string) $args['code'] : '';
$label = isset( $args['label'] ) ? (string) $args['label'] : '';

if ( '' === $slot || '' === $code ) {
	return;
}

$modifier = sanitize_html_class( str_replace( '_', '-', $slot ) );
?>

<div
	class="ao-ad ao-ad--<?php echo esc_attr( $modifier ); ?>"
	data-ad-slot="<?php echo esc_attr( $slot ); ?>"
	role="complementary"
	aria-label="<?php echo esc_attr( $label ); ?>"
>
	<span class="ao-ad__label screen-reader-text"><?php echo esc_html( $label ); ?></span>
	<div class="ao-ad__inner">
		<?php
		// Ad code is sanitized via azunta_optimize_sanitize_ad_code() (extended wp_kses).
		echo $code; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		?>
	</div>
</div>
