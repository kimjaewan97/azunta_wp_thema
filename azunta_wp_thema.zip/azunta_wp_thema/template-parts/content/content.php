<?php
/**
 * Default content template (archives / blog index).
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry ao-card' ); ?>>
	<?php azunta_optimize_post_thumbnail(); ?>

	<header class="entry-header">
		<?php
		the_title(
			sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ),
			'</a></h2>'
		);
		?>

		<?php if ( 'post' === get_post_type() ) : ?>
			<div class="entry-meta">
				<?php
				azunta_optimize_posted_on();
				azunta_optimize_posted_by();
				?>
			</div>
		<?php endif; ?>
	</header>

	<div class="entry-summary">
		<?php the_excerpt(); ?>
		<a class="more-link" href="<?php the_permalink(); ?>">
			<?php
			printf(
				/* translators: %s: post title */
				esc_html__( '더 읽기 %s', 'azunta-optimize' ),
				'<span class="screen-reader-text">' . wp_kses_post( get_the_title() ) . '</span>'
			);
			?>
		</a>
	</div>
</article>
