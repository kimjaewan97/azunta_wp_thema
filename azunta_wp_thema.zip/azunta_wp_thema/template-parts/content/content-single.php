<?php
/**
 * Single post content.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$show_meta = (bool) get_theme_mod( 'azunta_optimize_show_single_meta', false );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<?php if ( 'post' === get_post_type() && $show_meta ) : ?>
			<div class="entry-meta">
				<?php
				azunta_optimize_posted_on();
				azunta_optimize_posted_by();
				?>
			</div>
		<?php endif; ?>
	</header>

	<?php
	// After Title Ad — directly under the title (before featured image). Best for AdSense.
	azunta_optimize_ad( 'after_title' );
	?>

	<?php azunta_optimize_post_thumbnail(); ?>

	<div class="entry-content">
		<?php
		the_content(
			sprintf(
				wp_kses(
					/* translators: %s: post title */
					__( '계속 읽기<span class="screen-reader-text"> "%s"</span>', 'azunta-optimize' ),
					array( 'span' => array( 'class' => array() ) )
				),
				wp_kses_post( get_the_title() )
			)
		);

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( '페이지:', 'azunta-optimize' ),
				'after'  => '</div>',
			)
		);
		?>
	</div>

	<footer class="entry-footer">
		<?php azunta_optimize_entry_footer(); ?>
	</footer>
</article>
