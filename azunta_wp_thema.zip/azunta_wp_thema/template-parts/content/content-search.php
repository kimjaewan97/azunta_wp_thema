<?php
/**
 * Search result item — horizontal post card.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry ao-card post-card' ); ?>>
	<div class="post-card__inner">
		<?php azunta_optimize_the_left_info_box( 'azunta-optimize-card' ); ?>

		<div class="post-card__body">
			<header class="entry-header post-card__header">
				<?php
				the_title(
					sprintf( '<h2 class="entry-title post-card__title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ),
					'</a></h2>'
				);
				?>
			</header>

			<div class="entry-summary post-card__excerpt">
				<?php the_excerpt(); ?>
			</div>

			<?php azunta_optimize_the_card_meta(); ?>
		</div>
	</div>
</article>
