<?php
/**
 * No results content.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title"><?php esc_html_e( '결과가 없습니다', 'azunta-optimize' ); ?></h1>
	</header>

	<div class="page-content">
		<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>
			<p>
				<?php
				printf(
					wp_kses(
						/* translators: 1: link to WP admin new post page */
						__( '첫 글을 작성해 볼까요? <a href="%1$s">여기서 시작하기</a>.', 'azunta-optimize' ),
						array( 'a' => array( 'href' => array() ) )
					),
					esc_url( admin_url( 'post-new.php' ) )
				);
				?>
			</p>
		<?php elseif ( is_search() ) : ?>
			<p><?php esc_html_e( '검색 결과가 없습니다. 다른 검색어로 다시 시도해 보세요.', 'azunta-optimize' ); ?></p>
			<?php get_search_form(); ?>
		<?php else : ?>
			<p><?php esc_html_e( '찾는 내용이 없습니다. 검색을 이용해 보세요.', 'azunta-optimize' ); ?></p>
			<?php get_search_form(); ?>
		<?php endif; ?>
	</div>
</section>
