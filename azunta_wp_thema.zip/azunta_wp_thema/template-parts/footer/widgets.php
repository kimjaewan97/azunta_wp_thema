<?php
/**
 * Footer widget columns.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$azunta_optimize_footer_sidebars = array( 'footer-1', 'footer-2', 'footer-3' );
$azunta_optimize_has_footer      = false;

foreach ( $azunta_optimize_footer_sidebars as $azunta_optimize_sidebar_id ) {
	if ( is_active_sidebar( $azunta_optimize_sidebar_id ) ) {
		$azunta_optimize_has_footer = true;
		break;
	}
}

if ( ! $azunta_optimize_has_footer ) {
	return;
}
?>

<div class="footer-widgets">
	<?php foreach ( $azunta_optimize_footer_sidebars as $azunta_optimize_sidebar_id ) : ?>
		<div class="footer-widget-column">
			<?php
			if ( is_active_sidebar( $azunta_optimize_sidebar_id ) ) {
				dynamic_sidebar( $azunta_optimize_sidebar_id );
			}
			?>
		</div>
	<?php endforeach; ?>
</div>
