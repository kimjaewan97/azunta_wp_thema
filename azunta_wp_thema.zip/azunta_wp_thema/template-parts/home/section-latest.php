<?php
/**
 * Homepage: latest posts section.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$title = (string) get_theme_mod( 'azunta_optimize_home_latest_title', '최신 글' );
if ( '' === $title ) {
	$title = '최신 글';
}

$query    = azunta_optimize_get_home_latest_query();
$more_url = azunta_optimize_get_blog_more_url();
?>

<section class="ao-home-section ao-home-latest" aria-labelledby="ao-home-latest-title">
	<header class="ao-home-section__header">
		<h2 id="ao-home-latest-title" class="ao-home-section__title"><?php echo esc_html( $title ); ?></h2>
		<a class="ao-more-link" href="<?php echo esc_url( $more_url ); ?>">
			<?php esc_html_e( '더보기', 'azunta-optimize' ); ?>
			<span aria-hidden="true">→</span>
		</a>
	</header>

	<?php if ( $query->have_posts() ) : ?>
		<div class="ao-home-latest__list posts-list">
			<?php
			$ao_index = 0;
			while ( $query->have_posts() ) :
				$query->the_post();
				get_template_part(
					'template-parts/home/card',
					null,
					array( 'show_excerpt' => true )
				);

				if ( function_exists( 'azunta_optimize_should_show_archive_ad' ) && azunta_optimize_should_show_archive_ad( $ao_index ) ) {
					azunta_optimize_ad( 'archive_between' );
				}
				++$ao_index;
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	<?php else : ?>
		<p class="ao-home-empty"><?php esc_html_e( '아직 게시된 글이 없습니다.', 'azunta-optimize' ); ?></p>
	<?php endif; ?>
</section>
