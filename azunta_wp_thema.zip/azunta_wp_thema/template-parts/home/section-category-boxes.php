<?php
/**
 * Homepage: category boxes (navigation cards) above post lists.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! (bool) get_theme_mod( 'azunta_optimize_home_show_category_boxes', true ) ) {
	return;
}

$categories = azunta_optimize_get_home_category_boxes();
if ( empty( $categories ) ) {
	return;
}

$title = (string) get_theme_mod( 'azunta_optimize_home_category_boxes_title', '카테고리' );
?>

<section class="ao-home-section ao-home-cat-boxes" aria-labelledby="ao-home-cat-boxes-title">
	<?php if ( '' !== trim( $title ) ) : ?>
		<header class="ao-home-section__header">
			<h2 id="ao-home-cat-boxes-title" class="ao-home-section__title"><?php echo esc_html( $title ); ?></h2>
		</header>
	<?php else : ?>
		<h2 id="ao-home-cat-boxes-title" class="screen-reader-text"><?php esc_html_e( '카테고리', 'azunta-optimize' ); ?></h2>
	<?php endif; ?>

	<div class="ao-cat-boxes">
		<?php foreach ( $categories as $term ) : ?>
			<?php
			if ( ! $term instanceof WP_Term ) {
				continue;
			}
			$link = get_term_link( $term );
			if ( is_wp_error( $link ) ) {
				continue;
			}
			$count = (int) $term->count;
			?>
			<a class="ao-cat-box" href="<?php echo esc_url( $link ); ?>">
				<span class="ao-cat-box__name"><?php echo esc_html( $term->name ); ?></span>
				<span class="ao-cat-box__count">
					<?php
					printf(
						/* translators: %d: number of posts */
						esc_html( _n( '%d개 글', '%d개 글', $count, 'azunta-optimize' ) ),
						$count
					);
					?>
				</span>
				<span class="ao-cat-box__arrow" aria-hidden="true">→</span>
			</a>
		<?php endforeach; ?>
	</div>
</section>
