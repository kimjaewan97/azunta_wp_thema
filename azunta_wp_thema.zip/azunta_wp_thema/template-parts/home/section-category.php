<?php
/**
 * Homepage: single category column.
 *
 * @package Azunta_Optimize
 *
 * @var array $args {
 *     @type int    $cat_id Category ID.
 *     @type int    $count  Post count.
 *     @type string $side   left|right.
 *     @type string $title  Optional custom title.
 * }
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cat_id = isset( $args['cat_id'] ) ? (int) $args['cat_id'] : 0;
$count  = isset( $args['count'] ) ? (int) $args['count'] : 5;
$side   = isset( $args['side'] ) ? (string) $args['side'] : 'left';
$title  = isset( $args['title'] ) ? (string) $args['title'] : '';

if ( $cat_id <= 0 ) {
	return;
}

$term = get_term( $cat_id, 'category' );
if ( ! $term || is_wp_error( $term ) ) {
	return;
}

if ( '' === trim( $title ) ) {
	$title = $term->name;
}

$link  = get_term_link( $term );
$link  = is_wp_error( $link ) ? '' : $link;
$query = azunta_optimize_get_home_category_query( $cat_id, $count );
$sid   = 'ao-home-cat-' . sanitize_html_class( $side );
?>

<section class="ao-home-section ao-home-category ao-home-category--<?php echo esc_attr( $side ); ?>" aria-labelledby="<?php echo esc_attr( $sid ); ?>-title">
	<header class="ao-home-section__header">
		<h2 id="<?php echo esc_attr( $sid ); ?>-title" class="ao-home-section__title"><?php echo esc_html( $title ); ?></h2>
		<?php if ( $link ) : ?>
			<a class="ao-more-link" href="<?php echo esc_url( $link ); ?>">
				<?php esc_html_e( '더보기', 'azunta-optimize' ); ?>
				<span aria-hidden="true">→</span>
			</a>
		<?php endif; ?>
	</header>

	<?php if ( $query->have_posts() ) : ?>
		<div class="ao-home-category__list">
			<?php
			while ( $query->have_posts() ) :
				$query->the_post();
				get_template_part(
					'template-parts/home/card',
					null,
					array(
						'show_excerpt' => false,
						'compact'      => true,
						'pin_cat_id'   => $cat_id,
					)
				);
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	<?php else : ?>
		<p class="ao-home-empty"><?php esc_html_e( '이 카테고리에 글이 없습니다.', 'azunta-optimize' ); ?></p>
	<?php endif; ?>
</section>
