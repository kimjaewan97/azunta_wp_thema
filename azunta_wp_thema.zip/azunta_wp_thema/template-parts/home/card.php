<?php
/**
 * Compact post card for homepage sections.
 *
 * @package Azunta_Optimize
 *
 * @var array $args {
 *     @type bool $show_excerpt Whether to show excerpt.
 * }
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$show_excerpt = ! isset( $args['show_excerpt'] ) || (bool) $args['show_excerpt'];
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry ao-card ao-home-card' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php
			the_post_thumbnail(
				'medium_large',
				array(
					'alt' => the_title_attribute( array( 'echo' => false ) ),
				)
			);
			?>
		</a>
	<?php endif; ?>

	<header class="entry-header">
		<?php
		the_title(
			sprintf( '<h3 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ),
			'</a></h3>'
		);
		?>
		<div class="entry-meta">
			<?php azunta_optimize_posted_on(); ?>
		</div>
	</header>

	<?php if ( $show_excerpt ) : ?>
		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div>
	<?php endif; ?>
</article>
