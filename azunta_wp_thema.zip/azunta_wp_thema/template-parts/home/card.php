<?php
/**
 * Horizontal post card for homepage sections.
 *
 * @package Azunta_Optimize
 *
 * @var array $args {
 *     @type bool   $show_excerpt Whether to show excerpt.
 *     @type bool   $compact      Compact layout (category columns).
 * }
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$show_excerpt = ! isset( $args['show_excerpt'] ) || (bool) $args['show_excerpt'];
$compact      = isset( $args['compact'] ) && (bool) $args['compact'];

$classes = array( 'entry', 'ao-card', 'post-card', 'ao-home-card' );
if ( $compact ) {
	$classes[] = 'post-card--compact';
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	<div class="post-card__inner">
		<?php azunta_optimize_the_left_info_box( 'azunta-optimize-card' ); ?>

		<div class="post-card__body">
			<header class="entry-header post-card__header">
				<?php
				$pin_cat = isset( $args['pin_cat_id'] ) ? (int) $args['pin_cat_id'] : 0;
				if ( $pin_cat > 0 && function_exists( 'azunta_optimize_the_category_pin_badge' ) ) {
					azunta_optimize_the_category_pin_badge( $pin_cat );
				}

				$tag = $compact ? 'h3' : 'h2';
				the_title(
					sprintf(
						'<%1$s class="entry-title post-card__title"><a href="%2$s" rel="bookmark">',
						$tag,
						esc_url( get_permalink() )
					),
					sprintf( '</a></%s>', $tag )
				);
				?>
			</header>

			<?php if ( $show_excerpt ) : ?>
				<div class="entry-summary post-card__excerpt">
					<?php the_excerpt(); ?>
				</div>
			<?php endif; ?>

			<?php azunta_optimize_the_card_meta(); ?>
		</div>
	</div>
</article>
