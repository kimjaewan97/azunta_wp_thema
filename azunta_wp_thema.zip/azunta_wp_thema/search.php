<?php
/**
 * Search results template.
 *
 * @package Azunta_Optimize
 */

declare(strict_types=1);

get_header();
?>

<main id="primary" class="site-main">
	<div class="ao-container ao-layout">
		<div class="content-area">
			<?php if ( have_posts() ) : ?>

				<header class="page-header">
					<h1 class="page-title">
						<?php
						printf(
							/* translators: %s: search query */
							esc_html__( '검색 결과: %s', 'azunta-optimize' ),
							'<span>' . esc_html( get_search_query() ) . '</span>'
						);
						?>
					</h1>
				</header>

				<div class="posts-list">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/content/content', 'search' );
					endwhile;
					?>
				</div>

				<?php azunta_optimize_the_posts_navigation(); ?>

			<?php else : ?>

				<?php get_template_part( 'template-parts/content/content', 'none' ); ?>

			<?php endif; ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</main>

<?php
get_footer();
